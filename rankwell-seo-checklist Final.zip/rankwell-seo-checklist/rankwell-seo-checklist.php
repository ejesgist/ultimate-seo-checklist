<?php
/**
 * Plugin Name: Rankwell SEO Checklist
 * Plugin URI: https://github.com/ejesgist/rankwell-seo-checklist
 * Description: Lightweight on-page SEO checklist and audit tool designed as a preflight check for content before publishing.
 * Version: 1.3.0
 * Author: Omajemite Don
 * Author URI: https://ejesgist.com/developer/
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: rankwell-seo-checklist
 * Domain Path: /languages
 * Requires at least: 6.0
 * Tested up to: 6.9
 * Requires PHP: 8.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('RWSC_VERSION', '1.3.0');
define('RWSC_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('RWSC_PLUGIN_URL', plugin_dir_url(__FILE__));
define('RWSC_PLUGIN_BASENAME', plugin_basename(__FILE__));
define('RWSC_CACHE_TABLE', 'rwsc_cache');
define('RWSC_NONCE_ACTION', 'rwsc_ajax_nonce');

/**
 * Load plugin text domain for translations
 */
function rwsc_load_textdomain() {
    load_plugin_textdomain(
        'rankwell-seo-checklist',
        false,
        dirname(RWSC_PLUGIN_BASENAME) . '/languages'
    );
}
add_action('plugins_loaded', 'rwsc_load_textdomain');

/**
 * PSR-4 Autoloader with correct path mapping
 */
spl_autoload_register(function ($class) {
    // Project namespace prefix
    $prefix = 'Rankwell\\SEO_Checklist\\';
    $base_dir = RWSC_PLUGIN_DIR . 'includes/';
    
    // Does the class use the namespace prefix?
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }
    
    // Get the relative class name
    $relative_class = substr($class, $len);
    
    // Convert namespace separators to directory separators
    $relative_path = str_replace('\\', '/', $relative_class);
    
    // Handle Engine namespace specially
    if (strpos($relative_path, 'Engine/') === 0) {
        // For Engine classes, they go in engine/ directory
        $sub_path = substr($relative_path, 7);
        $class_name = $sub_path;
        
        // Convert class name to WordPress format: class-lowercase-hyphenated.php
        $hyphenated = strtolower(preg_replace('/([a-zA-Z])(?=[A-Z])/', '$1-', $class_name));
        $hyphenated = str_replace('_', '-', $hyphenated);
        $file = $base_dir . 'engine/class-' . $hyphenated . '.php';
        
        if (file_exists($file)) {
            require $file;
            return;
        }
    } else {
        // For non-Engine classes (Plugin, Activator, Deactivator, Compatibility)
        $class_name = $relative_path;
        $hyphenated = strtolower(preg_replace('/([a-zA-Z])(?=[A-Z])/', '$1-', $class_name));
        $hyphenated = str_replace('_', '-', $hyphenated);
        $file = $base_dir . 'class-' . $hyphenated . '.php';
        
        if (file_exists($file)) {
            require $file;
            return;
        }
    }
});

// Register activation/deactivation hooks
register_activation_hook(RWSC_PLUGIN_BASENAME, ['Rankwell\SEO_Checklist\Activator', 'activate']);
register_deactivation_hook(RWSC_PLUGIN_BASENAME, ['Rankwell\SEO_Checklist\Deactivator', 'deactivate']);

// Initialize the plugin
add_action('init', function() {
    if (class_exists('Rankwell\SEO_Checklist\Plugin')) {
        Rankwell\SEO_Checklist\Plugin::get_instance();
    }
});