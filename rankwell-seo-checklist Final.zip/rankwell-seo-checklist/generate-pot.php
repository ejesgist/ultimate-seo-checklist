<?php
/**
 * Generate .pot file for Rankwell SEO Checklist
 * Run this from command line: php generate-pot.php
 */

$plugin_name = 'rankwell-seo-checklist';
$plugin_version = '1.3.0';
$plugin_dir = __DIR__;

// Find all PHP files
$files = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($plugin_dir, RecursiveDirectoryIterator::SKIP_DOTS)
);

$text_domains = [];
$strings = [];

foreach ($files as $file) {
    if ($file->getExtension() === 'php' && $file->getFilename() !== 'generate-pot.php') {
        $content = file_get_contents($file->getRealPath());
        
        // Find all __() and _e() calls
        preg_match_all('/__(?:\s*)?\([\'\"]([^\'\"]+)[\'\"](?:\s*,\s*[\'\"]([^\'\"]+)[\'\"])?\)/', $content, $matches);
        if (!empty($matches[1])) {
            foreach ($matches[1] as $index => $string) {
                $domain = $matches[2][$index] ?? 'rankwell-seo-checklist';
                if ($domain === 'rankwell-seo-checklist') {
                    $strings[$string] = $string;
                }
            }
        }
        
        preg_match_all('/_e(?:\s*)?\([\'\"]([^\'\"]+)[\'\"](?:\s*,\s*[\'\"]([^\'\"]+)[\'\"])?\)/', $content, $matches);
        if (!empty($matches[1])) {
            foreach ($matches[1] as $index => $string) {
                $domain = $matches[2][$index] ?? 'rankwell-seo-checklist';
                if ($domain === 'rankwell-seo-checklist') {
                    $strings[$string] = $string;
                }
            }
        }
        
        preg_match_all('/_x(?:\s*)?\([\'\"]([^\'\"]+)[\'\"](?:\s*,\s*[\'\"]([^\'\"]+)[\'\"](?:\s*,\s*[\'\"]([^\'\"]+)[\'\"])?)?\)/', $content, $matches);
        if (!empty($matches[1])) {
            foreach ($matches[1] as $index => $string) {
                $domain = $matches[3][$index] ?? 'rankwell-seo-checklist';
                if ($domain === 'rankwell-seo-checklist') {
                    $strings[$string] = $string;
                }
            }
        }
        
        preg_match_all('/_n(?:\s*)?\([\'\"]([^\'\"]+)[\'\"](?:\s*,\s*[\'\"]([^\'\"]+)[\'\"](?:\s*,\s*[^,]+(?:\s*,\s*[\'\"]([^\'\"]+)[\'\"])?)?)\)/', $content, $matches);
        if (!empty($matches[1])) {
            foreach ($matches[1] as $index => $string) {
                $domain = $matches[3][$index] ?? 'rankwell-seo-checklist';
                if ($domain === 'rankwell-seo-checklist') {
                    $strings[$string] = $string;
                    if (isset($matches[2][$index])) {
                        $strings[$matches[2][$index]] = $matches[2][$index];
                    }
                }
            }
        }
    }
}

// Sort strings
ksort($strings);

// Generate .pot content
$pot_content = 'msgid ""
msgstr ""
"Project-Id-Version: Rankwell SEO Checklist ' . $plugin_version . '\n"
"POT-Creation-Date: ' . date('Y-m-d H:iO') . '\n"
"PO-Revision-Date: ' . date('Y-m-d H:iO') . '\n"
"Last-Translator: \n"
"Language-Team: \n"
"Language: en_US\n"
"MIME-Version: 1.0\n"
"Content-Type: text/plain; charset=UTF-8\n"
"Content-Transfer-Encoding: 8bit\n"
"Plural-Forms: nplurals=2; plural=n != 1;\n"
"X-Generator: Rankwell SEO Checklist\n"
"X-Poedit-Basepath: ..\n"
"X-Poedit-SourceCharset: UTF-8\n"
"X-Poedit-SearchPath-0: .\n"
"X-Poedit-Bookmarks: \n"
"X-Textdomain-Support: yes\n"
"X-Poedit-KeywordsList: __;_e;_x:1,2c;_n:1,2;_n_noop:1,2;_nx:1,2,4c;_nx_noop:1,2,3c;esc_attr__;esc_html__;esc_attr_e;esc_html_e;esc_attr_x:1,2c;esc_html_x:1,2c;\n"
"\n";

foreach ($strings as $string) {
    $string = str_replace('"', '\"', $string);
    $pot_content .= "\nmsgid \"{$string}\"\nmsgstr \"\"\n";
}

// Save .pot file
$pot_file = __DIR__ . '/languages/rankwell-seo-checklist.pot';
file_put_contents($pot_file, $pot_content);

echo "Generated {$pot_file} with " . count($strings) . " strings.\n";