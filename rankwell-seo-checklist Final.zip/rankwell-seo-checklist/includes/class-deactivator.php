<?php
/**
 * Rankwell SEO Checklist - Deactivator Class
 * 
 * @package Rankwell\SEO_Checklist
 * @since 1.3.0
 */

namespace Rankwell\SEO_Checklist;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Deactivator
{
    /**
     * Deactivate the plugin
     */
    public static function deactivate()
    {
        // Clear scheduled events
        wp_clear_scheduled_hook('rwsc_daily_cleanup');
        
        // Clear transients
        self::cleanup_transients();
        
        // Remove any temporary data
        self::cleanup_temporary_data();
    }
    
    /**
     * Clean up transients
     */
    private static function cleanup_transients()
    {
        global $wpdb;
        
        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$wpdb->options} 
                WHERE option_name LIKE %s 
                OR option_name LIKE %s",
                '_transient_rwsc_%',
                '_transient_timeout_rwsc_%'
            )
        );
    }
    
    /**
     * Clean up temporary data
     */
    private static function cleanup_temporary_data()
    {
        $temp_dir = RWSC_PLUGIN_DIR . 'tmp/';
        if (is_dir($temp_dir)) {
            array_map('unlink', glob("$temp_dir/*.*"));
            rmdir($temp_dir);
        }
    }
}