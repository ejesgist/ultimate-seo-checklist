<?php
/**
 * Rankwell SEO Checklist - Activator Class
 * 
 * @package Rankwell\SEO_Checklist
 * @since 1.3.0
 */

namespace Rankwell\SEO_Checklist;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Activator
{
    /**
     * Activate the plugin
     */
    public static function activate()
    {
        // Set default options
        add_option('rwsc_version', RWSC_VERSION);
        add_option('rwsc_auto_check', 1);
        add_option('rwsc_cache_duration', 300);
        add_option('rwsc_compatibility_mode', 1);
        add_option('rwsc_minimal_mode', 0);
        add_option('rwsc_enabled_checks', self::get_default_checks());
        
        // Create cache table
        self::setup_cache_table();
        
        // Create database indexes
        self::create_indexes();
        
        // Clear any existing cache
        self::clear_old_cache();
    }
    
    /**
     * Get default checks
     */
    public static function get_default_checks()
    {
        return [
            'title_keyword' => 1,
            'title_word_count' => 1,
            'title_length' => 1,
            'title_number' => 1,
            'title_power_words' => 1,
            'title_uncommon_words' => 1,
            'title_sentiment' => 1,
            'meta_description' => 1,
            'url_slug' => 1,
            'content_length' => 1,
            'keyword_density' => 1,
            'first_paragraph' => 1,
            'headings' => 1,
            'image_alt' => 1,
            'keyword_bolded' => 1,
            'internal_links' => 1,
            'readability' => 1,
            'paragraph_structure' => 1,
            'content_conclusion' => 1,
            'transition_words' => 1,
            'quick_answer' => 1,
            'keyword_anchor' => 1,
            'authority_links' => 1,
            'content_freshness' => 1,
            'featured_image' => 1,
            'image_dimensions' => 1,
            'image_file_size' => 1,
            'word_form_recognition' => 1,
            'passive_voice' => 1,
            'consecutive_sentences' => 1,
            'subheading_distribution' => 1,
            'keyword_in_subheadings' => 1,
            'content_uniqueness' => 1,
            'emotional_tone' => 1,
            'content_formatting' => 1,
            'content_breaks' => 1,
            'related_posts' => 1,
            'consistency_check' => 1,
            'opening_hook' => 1,
            'scannability_score' => 1,
            'jargon_detection' => 1,
            'faq_anticipation' => 1,
            'internal_link_suggestions' => 1
        ];
    }
    
    /**
     * Setup cache table
     */
    private static function setup_cache_table()
    {
        global $wpdb;
        
        $table_name = $wpdb->prefix . RWSC_CACHE_TABLE;
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS {$table_name} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            post_id bigint(20) NOT NULL,
            keyword_hash varchar(32) NOT NULL,
            content_hash varchar(32) NOT NULL,
            results longtext NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY post_keyword_content (post_id, keyword_hash, content_hash),
            KEY created_at (created_at),
            KEY keyword_hash (keyword_hash),
            KEY content_hash (content_hash)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    /**
     * Create database indexes for performance
     */
    private static function create_indexes()
    {
        global $wpdb;
        
        // Check if index already exists before creating
        $index_exists = $wpdb->get_var(
            $wpdb->prepare(
                "SHOW INDEX FROM {$wpdb->postmeta} WHERE Key_name = %s",
                'rwsc_keyword_idx'
            )
        );
        
        if (!$index_exists) {
            $wpdb->query(
                "ALTER TABLE {$wpdb->postmeta} ADD INDEX rwsc_keyword_idx (meta_key, meta_value(100))"
            );
        }
    }
    
    /**
     * Clear old cache entries
     */
    private static function clear_old_cache()
    {
        global $wpdb;
        
        $table_name = $wpdb->prefix . RWSC_CACHE_TABLE;
        
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'");
        if ($table_exists) {
            $wpdb->query(
                "DELETE FROM {$table_name} 
                WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)"
            );
        }
    }
}