<?php
/**
 * Rankwell SEO Checklist - Main Plugin Class
 * 
 * @package Rankwell\SEO_Checklist
 * @since 1.3.0
 */

namespace Rankwell\SEO_Checklist;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Plugin
{
    private static $instance = null;
    private $loaded_components = [];
    
    public static function get_instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct()
    {
        $this->setup_hooks();
        $this->check_compatibility();
    }
    
    private function setup_hooks()
    {
        // Activation/Deactivation
        register_activation_hook(RWSC_PLUGIN_BASENAME, [Activator::class, 'activate']);
        register_deactivation_hook(RWSC_PLUGIN_BASENAME, [Deactivator::class, 'deactivate']);
        
        // Admin hooks
        add_action('add_meta_boxes', [$this, 'add_preflight_metabox']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
        add_action('admin_init', [$this, 'register_settings']);
        
        // Gutenberg specific hooks
        add_action('enqueue_block_editor_assets', [$this, 'enqueue_gutenberg_assets']);
        
        // AJAX handlers
        add_action('wp_ajax_rwsc_run_preflight', [$this, 'ajax_run_preflight']);
        add_action('wp_ajax_rwsc_save_keyword', [$this, 'ajax_save_keyword']);
        add_action('wp_ajax_rwsc_toggle_check', [$this, 'ajax_toggle_check']);
        
        // Load textdomain
        add_action('plugins_loaded', [$this, 'load_textdomain']);
        
        // Add admin menu page
        add_action('admin_menu', [$this, 'add_admin_menu']);
        
        // Add help tab
        add_action('admin_head', [$this, 'add_help_tab']);
        
        // Save keyword on post save
        add_action('save_post', [$this, 'save_focus_keyword'], 10, 2);
        
        // Cleanup on post delete
        add_action('delete_post', [$this, 'cleanup_post_data']);
        
        // Register page builder support
        $this->register_page_builder_support();
    }
    
    /**
     * Check compatibility requirements
     */
    public function check_compatibility()
    {
        // Check for required PHP version
        if (version_compare(PHP_VERSION, '7.4', '<')) {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error"><p>';
                printf(
                    __('Rankwell SEO Checklist requires PHP 7.4 or higher. Your server is running PHP %s.', 'rankwell-seo-checklist'),
                    PHP_VERSION
                );
                echo '</p></div>';
            });
            return;
        }
        
        // Check for WordPress version
        global $wp_version;
        if (version_compare($wp_version, '5.8', '<')) {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error"><p>';
                _e('Rankwell SEO Checklist requires WordPress 5.8 or higher.', 'rankwell-seo-checklist');
                echo '</p></div>';
            });
        }
    }
    
    /**
     * Load text domain
     */
    public function load_textdomain()
    {
        load_plugin_textdomain(
            'rankwell-seo-checklist',
            false,
            dirname(RWSC_PLUGIN_BASENAME) . '/languages'
        );
    }
    
    /**
     * Register support for page builders
     */
    private function register_page_builder_support()
    {
        // Elementor
        add_action('elementor/editor/after_enqueue_scripts', [$this, 'enqueue_admin_assets']);
        
        // Beaver Builder
        add_action('fl_builder_after_control_actions', [$this, 'enqueue_admin_assets']);
        
        // WPBakery
        add_action('vc_backend_editor_enqueue_js_css', [$this, 'enqueue_admin_assets']);
        
        // Divi
        add_action('et_fb_enqueue_assets', [$this, 'enqueue_admin_assets']);
        
        // Bricks Builder
        add_action('bricks/builder/after_enqueue_scripts', [$this, 'enqueue_admin_assets']);
    }
    
    /**
     * Enqueue assets for Gutenberg editor
     */
    public function enqueue_gutenberg_assets()
    {
        global $post;
        
        $post_type = get_post_type();
        $supported_types = apply_filters('rwsc_post_types', ['post', 'page']);
        
        if (!in_array($post_type, $supported_types)) {
            return;
        }
        
        // Load CSS
        wp_enqueue_style(
            'rwsc-gutenberg',
            RWSC_PLUGIN_URL . 'assets/css/rwsc-gutenberg.css',
            [],
            RWSC_VERSION
        );
        
        // Load JavaScript for Gutenberg
        wp_enqueue_script(
            'rwsc-gutenberg',
            RWSC_PLUGIN_URL . 'assets/js/rwsc-gutenberg.js',
            ['wp-plugins', 'wp-edit-post', 'wp-element', 'wp-components', 'wp-data', 'wp-i18n'],
            RWSC_VERSION,
            true
        );
        
        // Get saved keyword
        $saved_keyword = '';
        if ($post && isset($post->ID)) {
            $saved_keyword = get_post_meta($post->ID, '_rwsc_focus_keyword', true);
        }
        
        // Localize script
        wp_localize_script('rwsc-gutenberg', 'rwscConfig', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'postId' => $post ? $post->ID : 0,
            'savedKeyword' => $saved_keyword,
            'nonce' => wp_create_nonce(RWSC_NONCE_ACTION),
            'autoCheck' => get_option('rwsc_auto_check', 1),
            'minimalMode' => get_option('rwsc_minimal_mode', 0),
            'enabledChecks' => get_option('rwsc_enabled_checks', Activator::get_default_checks()),
            'i18n' => [
                'title' => __('SEO Checklist', 'rankwell-seo-checklist'),
                'focusKeyword' => __('Focus Keyword:', 'rankwell-seo-checklist'),
                'placeholder' => __('Enter primary keyword', 'rankwell-seo-checklist'),
                'runCheck' => __('Run Checklist', 'rankwell-seo-checklist'),
                'autoCheckEnabled' => __('(Auto-check enabled)', 'rankwell-seo-checklist'),
                'analyzing' => __('Analyzing...', 'rankwell-seo-checklist'),
                'score' => __('Score:', 'rankwell-seo-checklist'),
                'suggestions' => __('Suggestions for Improvement', 'rankwell-seo-checklist'),
                'checks' => __('Checks', 'rankwell-seo-checklist'),
                'high' => __('High', 'rankwell-seo-checklist'),
                'medium' => __('Medium', 'rankwell-seo-checklist'),
                'low' => __('Low', 'rankwell-seo-checklist')
            ]
        ]);
        
        // Set wp.i18n locale
        if (function_exists('wp_set_script_translations')) {
            wp_set_script_translations('rwsc-gutenberg', 'rankwell-seo-checklist');
        }
    }
    
    /**
     * Add preflight metabox (works with both classic and block editor)
     */
    public function add_preflight_metabox()
    {
        $post_types = apply_filters('rwsc_post_types', ['post', 'page']);
        
        foreach ($post_types as $post_type) {
            add_meta_box(
                'rwsc_preflight_box',
                __('SEO Checklist', 'rankwell-seo-checklist'),
                [$this, 'render_preflight_metabox'],
                $post_type,
                'side',
                'high',
                [
                    '__back_compat_meta_box' => false,
                    '__block_editor_compatible_meta_box' => true,
                ]
            );
        }
    }
    
    /**
     * Render the metabox content
     */
    public function render_preflight_metabox($post)
    {
        wp_nonce_field('rwsc_save_meta', 'rwsc_nonce');
        
        $saved_keyword = get_post_meta($post->ID, '_rwsc_focus_keyword', true);
        $auto_check = get_option('rwsc_auto_check', 1);
        $minimal_mode = get_option('rwsc_minimal_mode', 0);
        
        ?>
        <div class="rwsc-metabox" data-minimal-mode="<?php echo $minimal_mode ? '1' : '0'; ?>">
            <div class="rwsc-keyword-section">
                <label for="rwsc_focus_keyword">
                    <strong><?php _e('Focus Keyword:', 'rankwell-seo-checklist'); ?></strong>
                </label>
                <input type="text" 
                       id="rwsc_focus_keyword" 
                       name="rwsc_focus_keyword" 
                       value="<?php echo esc_attr($saved_keyword); ?>"
                       placeholder="<?php _e('Enter primary keyword', 'rankwell-seo-checklist'); ?>"
                       class="rwsc-keyword-input"
                       data-post-id="<?php echo $post->ID; ?>">
            </div>
            
            <div class="rwsc-actions">
                <button type="button" id="rwsc_run_check" class="button button-primary button-small">
                    <?php _e('Run Checklist', 'rankwell-seo-checklist'); ?>
                </button>
                <span class="rwsc-auto-check-info" style="<?php echo $auto_check ? '' : 'display:none;'; ?>">
                    <?php _e('(Auto-check enabled)', 'rankwell-seo-checklist'); ?>
                </span>
            </div>
            
            <div class="rwsc-results-container" style="display: none;">
                <div class="rwsc-score-summary">
                    <div class="rwsc-overall-score">
                        <span class="rwsc-score-label"><?php _e('Score:', 'rankwell-seo-checklist'); ?></span>
                        <span class="rwsc-score-value">--</span>/100
                    </div>
                    <div class="rwsc-progress-bar">
                        <div class="rwsc-progress-fill"></div>
                    </div>
                </div>
                
                <div class="rwsc-checklist">
                    <!-- Results will be loaded here -->
                </div>
                
                <div class="rwsc-suggestions">
                    <!-- Suggestions will be loaded here -->
                </div>
            </div>
            
            <div class="rwsc-loading" style="display: none;">
                <div class="rwsc-spinner"></div>
                <span><?php _e('Running checks...', 'rankwell-seo-checklist'); ?></span>
            </div>
        </div>
        <?php
    }
    
    /**
     * Enqueue admin assets for classic editor
     */
    public function enqueue_admin_assets($hook)
    {
        global $post;
        
        // Load on post edit screens
        if (!in_array($hook, ['post.php', 'post-new.php'])) {
            return;
        }
        
        // Check if we're editing a supported post type
        $post_type = get_post_type();
        $supported_types = apply_filters('rwsc_post_types', ['post', 'page']);
        
        if (!in_array($post_type, $supported_types)) {
            return;
        }
        
        // Load CSS
        wp_enqueue_style(
            'rwsc-admin',
            RWSC_PLUGIN_URL . 'assets/css/rwsc-admin.css',
            [],
            RWSC_VERSION
        );
        
        // Load JavaScript
        wp_enqueue_script(
            'rwsc-admin',
            RWSC_PLUGIN_URL . 'assets/js/rwsc-admin.js',
            ['jquery', 'wp-i18n'],
            RWSC_VERSION,
            true
        );
        
        // Set wp.i18n locale
        if (function_exists('wp_set_script_translations')) {
            wp_set_script_translations('rwsc-admin', 'rankwell-seo-checklist');
        }
        
        // Get post ID
        $post_id = $post ? $post->ID : 0;
        
        // Localize script
        wp_localize_script('rwsc-admin', 'rwscConfig', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'postId' => $post_id,
            'nonce' => wp_create_nonce(RWSC_NONCE_ACTION),
            'autoCheck' => get_option('rwsc_auto_check', 1),
            'minimalMode' => get_option('rwsc_minimal_mode', 0),
            'enabledChecks' => get_option('rwsc_enabled_checks', Activator::get_default_checks()),
            'debounceTime' => 2000,
            'debug' => defined('WP_DEBUG') && WP_DEBUG,
            'i18n' => [
                'analyzing' => __('Analyzing...', 'rankwell-seo-checklist'),
                'error' => __('Error:', 'rankwell-seo-checklist'),
                'enterKeyword' => __('Please enter a focus keyword', 'rankwell-seo-checklist'),
                'noContent' => __('No content to analyze', 'rankwell-seo-checklist'),
                'saving' => __('Saving...', 'rankwell-seo-checklist'),
                'saved' => __('Saved', 'rankwell-seo-checklist'),
                'checksPassed' => __('All checks passed!', 'rankwell-seo-checklist'),
                'checksWarning' => __('Some issues need attention', 'rankwell-seo-checklist'),
                'checksFailed' => __('Multiple issues found', 'rankwell-seo-checklist'),
                'noChecks' => __('No checks to display', 'rankwell-seo-checklist'),
                'suggestions' => __('Suggestions for Improvement', 'rankwell-seo-checklist'),
                'toggleCheck' => __('Toggle Check', 'rankwell-seo-checklist')
            ]
        ]);
    }
    
    /**
     * Add help tab to settings page
     */
    public function add_help_tab()
    {
        $screen = get_current_screen();
        
        if (!$screen || !in_array($screen->id, ['toplevel_page_rankwell-seo-checklist', 'seo-checklist_page_rankwell-seo-checklist-settings'])) {
            return;
        }
        
        $screen->add_help_tab([
            'id'      => 'rwsc-help',
            'title'   => __('How to Use', 'rankwell-seo-checklist'),
            'content' => '<p>' . __('Enter your focus keyword and click Run Checklist to analyze your content.', 'rankwell-seo-checklist') . '</p>' .
                        '<p>' . __('The plugin works with:', 'rankwell-seo-checklist') . '</p>' .
                        '<ul>' .
                        '<li>✓ ' . __('Gutenberg (Block Editor)', 'rankwell-seo-checklist') . '</li>' .
                        '<li>✓ ' . __('Classic Editor', 'rankwell-seo-checklist') . '</li>' .
                        '<li>✓ ' . __('Elementor', 'rankwell-seo-checklist') . '</li>' .
                        '<li>✓ ' . __('Beaver Builder', 'rankwell-seo-checklist') . '</li>' .
                        '<li>✓ ' . __('WPBakery', 'rankwell-seo-checklist') . '</li>' .
                        '<li>✓ ' . __('Divi', 'rankwell-seo-checklist') . '</li>' .
                        '</ul>'
        ]);
        
        $screen->set_help_sidebar(
            '<p><strong>' . __('More Information', 'rankwell-seo-checklist') . '</strong></p>' .
            '<p><a href="https://github.com/ejesgist/rankwell-seo-checklist" target="_blank">' . __('Documentation', 'rankwell-seo-checklist') . '</a></p>'
        );
    }
    
    /**
     * Register settings
     */
    public function register_settings()
    {
        register_setting('rwsc_settings', 'rwsc_auto_check', [
            'type' => 'boolean',
            'default' => 1,
            'sanitize_callback' => [$this, 'sanitize_boolean']
        ]);
        
        register_setting('rwsc_settings', 'rwsc_cache_duration', [
            'type' => 'integer',
            'default' => 300,
            'sanitize_callback' => [$this, 'sanitize_cache_duration']
        ]);
        
        register_setting('rwsc_settings', 'rwsc_compatibility_mode', [
            'type' => 'boolean',
            'default' => 1,
            'sanitize_callback' => [$this, 'sanitize_boolean']
        ]);
        
        register_setting('rwsc_settings', 'rwsc_minimal_mode', [
            'type' => 'boolean',
            'default' => 0,
            'sanitize_callback' => [$this, 'sanitize_boolean']
        ]);
        
        register_setting('rwsc_settings', 'rwsc_enabled_checks', [
            'type' => 'array',
            'default' => Activator::get_default_checks(),
            'sanitize_callback' => [$this, 'sanitize_enabled_checks']
        ]);
        
        register_setting('rwsc_settings', 'rwsc_delete_data_on_uninstall', [
            'type' => 'boolean',
            'default' => 0,
            'sanitize_callback' => [$this, 'sanitize_boolean']
        ]);
    }
    
    /**
     * Sanitize boolean values
     */
    public function sanitize_boolean($value)
    {
        return $value ? 1 : 0;
    }
    
    /**
     * Sanitize cache duration
     */
    public function sanitize_cache_duration($value)
    {
        $valid_durations = [0, 60, 300, 900, 1800, 3600, 7200];
        return in_array((int)$value, $valid_durations) ? (int)$value : 300;
    }
    
    /**
     * Sanitize enabled checks
     */
    public function sanitize_enabled_checks($value)
    {
        if (!is_array($value)) {
            return Activator::get_default_checks();
        }
        
        $default_checks = Activator::get_default_checks();
        $sanitized = [];
        
        foreach ($default_checks as $check_id => $default_value) {
            $sanitized[$check_id] = isset($value[$check_id]) ? 1 : 0;
        }
        
        return $sanitized;
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu()
    {
        add_menu_page(
            __('Rankwell SEO Checklist', 'rankwell-seo-checklist'),
            __('SEO Checklist', 'rankwell-seo-checklist'),
            'manage_options',
            'rankwell-seo-checklist',
            [$this, 'render_admin_page'],
            'dashicons-search',
            81
        );
        
        add_submenu_page(
            'rankwell-seo-checklist',
            __('Settings', 'rankwell-seo-checklist'),
            __('Settings', 'rankwell-seo-checklist'),
            'manage_options',
            'rankwell-seo-checklist-settings',
            [$this, 'render_settings_page']
        );
        
        add_submenu_page(
            'rankwell-seo-checklist',
            __('About', 'rankwell-seo-checklist'),
            __('About', 'rankwell-seo-checklist'),
            'manage_options',
            'rankwell-seo-checklist-about',
            [$this, 'render_about_page']
        );
    }
    
    /**
     * Render admin page
     */
    public function render_admin_page()
    {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'rankwell-seo-checklist'));
        }
        
        ?>
        <div class="wrap">
            <h1><?php _e('Rankwell SEO Checklist', 'rankwell-seo-checklist'); ?></h1>
            
            <div class="rwsc-admin-dashboard">
                <div class="rwsc-dashboard-main">
                    <div class="rwsc-info-card">
                        <h2><?php _e('Welcome to Rankwell SEO Checklist', 'rankwell-seo-checklist'); ?></h2>
                        <p><?php _e('Rankwell SEO Checklist is a lightweight on-page SEO audit tool that helps you optimize your content before publishing.', 'rankwell-seo-checklist'); ?></p>
                        <p><?php _e('To get started:', 'rankwell-seo-checklist'); ?></p>
                        <ol>
                            <li><?php _e('Edit any post or page', 'rankwell-seo-checklist'); ?></li>
                            <li><?php _e('Enter your focus keyword in the SEO Checklist metabox', 'rankwell-seo-checklist'); ?></li>
                            <li><?php _e('Click "Run Checklist" to analyze your content', 'rankwell-seo-checklist'); ?></li>
                            <li><?php _e('Follow the suggestions to improve your SEO', 'rankwell-seo-checklist'); ?></li>
                        </ol>
                    </div>
                    
                    <div class="rwsc-info-card">
                        <h2><?php _e('Recent Checks', 'rankwell-seo-checklist'); ?></h2>
                        <?php
                        $args = [
                            'post_type' => 'any',
                            'posts_per_page' => 10,
                            'meta_key' => '_rwsc_focus_keyword',
                            'meta_compare' => 'EXISTS'
                        ];
                        $recent_posts = get_posts($args);
                        
                        if ($recent_posts) {
                            echo '<ul class="rwsc-recent-posts">';
                            foreach ($recent_posts as $post) {
                                $keyword = get_post_meta($post->ID, '_rwsc_focus_keyword', true);
                                echo '<li>';
                                echo '<a href="' . get_edit_post_link($post->ID) . '">' . esc_html($post->post_title) . '</a>';
                                echo ' <span class="rwsc-keyword-badge">' . esc_html($keyword) . '</span>';
                                echo '</li>';
                            }
                            echo '</ul>';
                        } else {
                            echo '<p>' . __('No posts with focus keywords yet.', 'rankwell-seo-checklist') . '</p>';
                        }
                        ?>
                    </div>
                </div>
                
                <div class="rwsc-dashboard-sidebar">
                    <div class="rwsc-info-box">
                        <h3><?php _e('Plugin Information', 'rankwell-seo-checklist'); ?></h3>
                        <p><?php _e('Version:', 'rankwell-seo-checklist'); ?> <?php echo RWSC_VERSION; ?></p>
                        <p><?php _e('A lightweight preflight check for on-page SEO.', 'rankwell-seo-checklist'); ?></p>
                    </div>
                    
                    <div class="rwsc-info-box">
                        <h3><?php _e('Compatibility', 'rankwell-seo-checklist'); ?></h3>
                        <ul>
                            <li>✓ Yoast SEO</li>
                            <li>✓ Rank Math</li>
                            <li>✓ All In One SEO</li>
                            <li>✓ SEOPress</li>
                            <li>✓ The SEO Framework</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        
        <style>
        .rwsc-admin-dashboard {
            display: flex;
            gap: 30px;
            margin-top: 20px;
        }
        .rwsc-dashboard-main {
            flex: 3;
        }
        .rwsc-dashboard-sidebar {
            flex: 1;
        }
        .rwsc-info-card {
            background: #fff;
            border: 1px solid #ccd0d4;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 1px 1px rgba(0,0,0,.04);
        }
        .rwsc-info-card h2 {
            margin-top: 0;
            margin-bottom: 15px;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
        }
        .rwsc-info-box {
            background: #fff;
            border: 1px solid #ccd0d4;
            padding: 15px;
            margin-bottom: 20px;
        }
        .rwsc-info-box h3 {
            margin-top: 0;
            border-bottom: 1px solid #ddd;
            padding-bottom: 10px;
        }
        .rwsc-recent-posts {
            margin: 0;
            padding: 0;
        }
        .rwsc-recent-posts li {
            padding: 8px 0;
            border-bottom: 1px solid #f0f0f1;
        }
        .rwsc-keyword-badge {
            background: #f0f0f1;
            padding: 2px 6px;
            border-radius: 3px;
            font-size: 11px;
            margin-left: 8px;
        }
        </style>
        <?php
    }
    
    /**
     * Render about page
     */
    public function render_about_page()
    {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'rankwell-seo-checklist'));
        }
        
        ?>
        <div class="wrap">
            <h1><?php _e('About Rankwell SEO Checklist', 'rankwell-seo-checklist'); ?></h1>
            
            <div class="rwsc-about-container">
                <div class="rwsc-about-section">
                    <h2><?php _e('What is Rankwell SEO Checklist?', 'rankwell-seo-checklist'); ?></h2>
                    <p><?php _e('Rankwell SEO Checklist is a lightweight on-page SEO checklist and audit tool designed as a preflight check for content before publishing.', 'rankwell-seo-checklist'); ?></p>
                </div>
                
                <div class="rwsc-about-section">
                    <h2><?php _e('Features', 'rankwell-seo-checklist'); ?></h2>
                    <ul>
                        <li><strong><?php _e('Lightweight & Fast:', 'rankwell-seo-checklist'); ?></strong> <?php _e('Minimal impact on site performance', 'rankwell-seo-checklist'); ?></li>
                        <li><strong><?php _e('SEO Plugin Compatible:', 'rankwell-seo-checklist'); ?></strong> <?php _e('Works alongside major SEO plugins', 'rankwell-seo-checklist'); ?></li>
                        <li><strong><?php _e('Real-time Analysis:', 'rankwell-seo-checklist'); ?></strong> <?php _e('Check SEO as you type with auto-refresh', 'rankwell-seo-checklist'); ?></li>
                        <li><strong><?php _e('40+ Essential Checks:', 'rankwell-seo-checklist'); ?></strong> <?php _e('Comprehensive SEO analysis', 'rankwell-seo-checklist'); ?></li>
                        <li><strong><?php _e('Smart Caching:', 'rankwell-seo-checklist'); ?></strong> <?php _e('Configurable cache durations', 'rankwell-seo-checklist'); ?></li>
                        <li><strong><?php _e('Actionable Suggestions:', 'rankwell-seo-checklist'); ?></strong> <?php _e('Clear recommendations', 'rankwell-seo-checklist'); ?></li>
                    </ul>
                </div>
            </div>
        </div>
        
        <style>
        .rwsc-about-container {
            max-width: 800px;
            margin-top: 20px;
        }
        .rwsc-about-section {
            background: #fff;
            border: 1px solid #ccd0d4;
            padding: 20px;
            margin-bottom: 20px;
        }
        .rwsc-about-section h2 {
            margin-top: 0;
            margin-bottom: 15px;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
        }
        </style>
        <?php
    }
    
    /**
     * Render settings page
     */
    public function render_settings_page()
    {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'rankwell-seo-checklist'));
        }
        
        $enabled_checks = get_option('rwsc_enabled_checks', Activator::get_default_checks());
        $default_checks = Activator::get_default_checks();
        
        ?>
        <div class="wrap">
            <h1><?php _e('Rankwell SEO Checklist Settings', 'rankwell-seo-checklist'); ?></h1>
            
            <?php if (isset($_GET['settings-updated'])): ?>
                <div class="notice notice-success is-dismissible">
                    <p><?php _e('Settings saved successfully.', 'rankwell-seo-checklist'); ?></p>
                </div>
            <?php endif; ?>
            
            <div class="rwsc-settings-container">
                <div class="rwsc-settings-main">
                    <form method="post" action="options.php">
                        <?php settings_fields('rwsc_settings'); ?>
                        
                        <table class="form-table">
                            <tr>
                                <th scope="row"><?php _e('Auto Preflight Check', 'rankwell-seo-checklist'); ?></th>
                                <td>
                                    <label>
                                        <input type="checkbox" name="rwsc_auto_check" value="1" <?php checked(get_option('rwsc_auto_check', 1)); ?>>
                                        <?php _e('Run checks automatically while editing', 'rankwell-seo-checklist'); ?>
                                    </label>
                                </td>
                            </tr>
                            
                            <tr>
                                <th scope="row"><?php _e('Cache Duration', 'rankwell-seo-checklist'); ?></th>
                                <td>
                                    <select name="rwsc_cache_duration">
                                        <option value="0" <?php selected(get_option('rwsc_cache_duration', 300), 0); ?>><?php _e('No caching', 'rankwell-seo-checklist'); ?></option>
                                        <option value="60" <?php selected(get_option('rwsc_cache_duration', 300), 60); ?>><?php _e('1 minute', 'rankwell-seo-checklist'); ?></option>
                                        <option value="300" <?php selected(get_option('rwsc_cache_duration', 300), 300); ?>><?php _e('5 minutes', 'rankwell-seo-checklist'); ?></option>
                                        <option value="900" <?php selected(get_option('rwsc_cache_duration', 300), 900); ?>><?php _e('15 minutes', 'rankwell-seo-checklist'); ?></option>
                                        <option value="1800" <?php selected(get_option('rwsc_cache_duration', 300), 1800); ?>><?php _e('30 minutes', 'rankwell-seo-checklist'); ?></option>
                                        <option value="3600" <?php selected(get_option('rwsc_cache_duration', 300), 3600); ?>><?php _e('1 hour', 'rankwell-seo-checklist'); ?></option>
                                    </select>
                                </td>
                            </tr>
                            
                            <tr>
                                <th scope="row"><?php _e('Compatibility Mode', 'rankwell-seo-checklist'); ?></th>
                                <td>
                                    <label>
                                        <input type="checkbox" name="rwsc_compatibility_mode" value="1" <?php checked(get_option('rwsc_compatibility_mode', 1)); ?>>
                                        <?php _e('Enable enhanced compatibility with other SEO plugins', 'rankwell-seo-checklist'); ?>
                                    </label>
                                </td>
                            </tr>
                            
                            <tr>
                                <th scope="row"><?php _e('Minimal Mode', 'rankwell-seo-checklist'); ?></th>
                                <td>
                                    <label>
                                        <input type="checkbox" name="rwsc_minimal_mode" value="1" <?php checked(get_option('rwsc_minimal_mode', 0)); ?>>
                                        <?php _e('Enable minimal interface (fewer details)', 'rankwell-seo-checklist'); ?>
                                    </label>
                                </td>
                            </tr>
                            
                            <tr>
                                <th scope="row"><?php _e('Enabled Checks', 'rankwell-seo-checklist'); ?></th>
                                <td>
                                    <div class="rwsc-checks-grid">
                                        <?php foreach ($default_checks as $check_id => $default_value): ?>
                                            <label class="rwsc-check-toggle">
                                                <input type="checkbox" 
                                                       name="rwsc_enabled_checks[<?php echo esc_attr($check_id); ?>]" 
                                                       value="1" 
                                                       <?php checked(isset($enabled_checks[$check_id]) ? $enabled_checks[$check_id] : 1); ?>>
                                                <?php echo esc_html($this->get_check_label($check_id)); ?>
                                            </label>
                                        <?php endforeach; ?>
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                                <th scope="row"><?php _e('Data Management', 'rankwell-seo-checklist'); ?></th>
                                <td>
                                    <label>
                                        <input type="checkbox" name="rwsc_delete_data_on_uninstall" value="1" <?php checked(get_option('rwsc_delete_data_on_uninstall', 0)); ?>>
                                        <?php _e('Delete all data on uninstall', 'rankwell-seo-checklist'); ?>
                                    </label>
                                    <p class="description">
                                        <?php _e('WARNING: This will permanently delete all plugin data when uninstalling.', 'rankwell-seo-checklist'); ?>
                                    </p>
                                </td>
                            </tr>
                        </table>
                        
                        <?php submit_button(); ?>
                    </form>
                </div>
                
                <div class="rwsc-settings-sidebar">
                    <div class="rwsc-info-box">
                        <h3><?php _e('Plugin Information', 'rankwell-seo-checklist'); ?></h3>
                        <p><?php _e('Version:', 'rankwell-seo-checklist'); ?> <?php echo RWSC_VERSION; ?></p>
                    </div>
                </div>
            </div>
        </div>
        
        <style>
        .rwsc-settings-container {
            display: flex;
            gap: 30px;
            margin-top: 20px;
        }
        .rwsc-settings-main {
            flex: 3;
            background: #fff;
            padding: 20px;
            border: 1px solid #ccd0d4;
        }
        .rwsc-settings-sidebar {
            flex: 1;
        }
        .rwsc-info-box {
            background: #fff;
            border: 1px solid #ccd0d4;
            padding: 15px;
        }
        .rwsc-checks-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 10px;
            max-height: 300px;
            overflow-y: auto;
            padding: 10px;
            border: 1px solid #ddd;
            background: #f9f9f9;
        }
        .rwsc-check-toggle {
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 13px;
        }
        </style>
        <?php
    }
    
    /**
     * Get check label
     */
    private function get_check_label($check_id)
    {
        $labels = [
            'title_keyword' => __('Keyword in Title', 'rankwell-seo-checklist'),
            'title_word_count' => __('Title Word Count', 'rankwell-seo-checklist'),
            'title_length' => __('Title Length', 'rankwell-seo-checklist'),
            'title_number' => __('Title Contains Number', 'rankwell-seo-checklist'),
            'title_power_words' => __('Title Power Words', 'rankwell-seo-checklist'),
            'title_uncommon_words' => __('Title Uncommon Words', 'rankwell-seo-checklist'),
            'title_sentiment' => __('Title Sentiment', 'rankwell-seo-checklist'),
            'meta_description' => __('Meta Description', 'rankwell-seo-checklist'),
            'url_slug' => __('URL Slug Length', 'rankwell-seo-checklist'),
            'content_length' => __('Content Length', 'rankwell-seo-checklist'),
            'keyword_density' => __('Keyword Density', 'rankwell-seo-checklist'),
            'first_paragraph' => __('Keyword in First Paragraph', 'rankwell-seo-checklist'),
            'headings' => __('Headings Structure', 'rankwell-seo-checklist'),
            'image_alt' => __('Image Alt Text', 'rankwell-seo-checklist'),
            'keyword_bolded' => __('Keyword Bolded', 'rankwell-seo-checklist'),
            'internal_links' => __('Internal Links', 'rankwell-seo-checklist'),
            'readability' => __('Readability', 'rankwell-seo-checklist'),
            'paragraph_structure' => __('Paragraph Structure', 'rankwell-seo-checklist'),
            'content_conclusion' => __('Content Conclusion', 'rankwell-seo-checklist'),
            'transition_words' => __('Transition Words', 'rankwell-seo-checklist'),
            'quick_answer' => __('Quick Answer Format', 'rankwell-seo-checklist'),
            'keyword_anchor' => __('Keyword as Anchor Text', 'rankwell-seo-checklist'),
            'authority_links' => __('Authority Links', 'rankwell-seo-checklist'),
            'content_freshness' => __('Content Freshness', 'rankwell-seo-checklist'),
            'featured_image' => __('Featured Image', 'rankwell-seo-checklist'),
            'image_dimensions' => __('Image Dimensions', 'rankwell-seo-checklist'),
            'image_file_size' => __('Image File Size', 'rankwell-seo-checklist'),
            'word_form_recognition' => __('Keyword Variations', 'rankwell-seo-checklist'),
            'passive_voice' => __('Passive Voice', 'rankwell-seo-checklist'),
            'consecutive_sentences' => __('Sentence Variety', 'rankwell-seo-checklist'),
            'subheading_distribution' => __('Subheading Distribution', 'rankwell-seo-checklist'),
            'keyword_in_subheadings' => __('Keyword in Subheadings', 'rankwell-seo-checklist'),
            'content_uniqueness' => __('Content Uniqueness', 'rankwell-seo-checklist'),
            'emotional_tone' => __('Emotional Tone', 'rankwell-seo-checklist'),
            'content_formatting' => __('Content Formatting', 'rankwell-seo-checklist'),
            'content_breaks' => __('Content Breaks', 'rankwell-seo-checklist'),
            'related_posts' => __('Related Posts', 'rankwell-seo-checklist'),
            'consistency_check' => __('Consistency', 'rankwell-seo-checklist'),
            'opening_hook' => __('Opening Hook', 'rankwell-seo-checklist'),
            'scannability_score' => __('Scannability', 'rankwell-seo-checklist'),
            'jargon_detection' => __('Jargon Detection', 'rankwell-seo-checklist'),
            'faq_anticipation' => __('FAQ Anticipation', 'rankwell-seo-checklist'),
            'internal_link_suggestions' => __('Internal Link Suggestions', 'rankwell-seo-checklist')
        ];
        
        return $labels[$check_id] ?? $check_id;
    }
    
    /**
     * AJAX: Run preflight
     */
    public function ajax_run_preflight()
    {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', RWSC_NONCE_ACTION)) {
            wp_send_json_error(['message' => __('Security check failed.', 'rankwell-seo-checklist')]);
        }
        
        // Check permissions
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(['message' => __('Insufficient permissions.', 'rankwell-seo-checklist')]);
        }
        
        // Get and validate input
        $post_id = isset($_POST['post_id']) ? absint($_POST['post_id']) : 0;
        $keyword = isset($_POST['keyword']) ? sanitize_text_field(trim($_POST['keyword'])) : '';
        $content = isset($_POST['content']) ? wp_kses_post($_POST['content']) : '';
        
        if (!$post_id || empty($keyword) || strlen($keyword) < 2) {
            wp_send_json_error(['message' => __('Invalid input data.', 'rankwell-seo-checklist')]);
        }
        
        // Run preflight check
        $results = Engine\Engine::run_preflight($post_id, $keyword, $content);
        
        wp_send_json_success($results);
    }
    
    /**
     * AJAX: Save keyword
     */
    public function ajax_save_keyword()
    {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', RWSC_NONCE_ACTION)) {
            wp_send_json_error(['message' => __('Security check failed.', 'rankwell-seo-checklist')]);
        }
        
        // Check permissions
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(['message' => __('Insufficient permissions.', 'rankwell-seo-checklist')]);
        }
        
        $post_id = isset($_POST['post_id']) ? absint($_POST['post_id']) : 0;
        $keyword = isset($_POST['keyword']) ? sanitize_text_field(trim($_POST['keyword'])) : '';
        
        if ($post_id) {
            if (!empty($keyword)) {
                update_post_meta($post_id, '_rwsc_focus_keyword', $keyword);
                wp_send_json_success(['message' => __('Keyword saved.', 'rankwell-seo-checklist')]);
            } else {
                delete_post_meta($post_id, '_rwsc_focus_keyword');
                wp_send_json_success(['message' => __('Keyword removed.', 'rankwell-seo-checklist')]);
            }
        }
        
        wp_send_json_error(['message' => __('Invalid data.', 'rankwell-seo-checklist')]);
    }
    
    /**
     * AJAX: Toggle check
     */
    public function ajax_toggle_check()
    {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', RWSC_NONCE_ACTION)) {
            wp_send_json_error(['message' => __('Security check failed.', 'rankwell-seo-checklist')]);
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Insufficient permissions.', 'rankwell-seo-checklist')]);
        }
        
        $check_id = isset($_POST['check_id']) ? sanitize_key($_POST['check_id']) : '';
        $enabled = isset($_POST['enabled']) ? (bool)$_POST['enabled'] : false;
        
        if (empty($check_id)) {
            wp_send_json_error(['message' => __('Invalid check ID.', 'rankwell-seo-checklist')]);
        }
        
        $enabled_checks = get_option('rwsc_enabled_checks', Activator::get_default_checks());
        $enabled_checks[$check_id] = $enabled ? 1 : 0;
        update_option('rwsc_enabled_checks', $enabled_checks);
        
        wp_send_json_success([
            'message' => __('Check updated.', 'rankwell-seo-checklist'),
            'enabled' => $enabled
        ]);
    }
    
    /**
     * Save focus keyword on post save
     */
    public function save_focus_keyword($post_id, $post)
    {
        // Check autosave
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        // Check permissions
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        // Check nonce
        if (!isset($_POST['rwsc_nonce']) || !wp_verify_nonce($_POST['rwsc_nonce'], 'rwsc_save_meta')) {
            return;
        }
        
        // Save or delete keyword
        if (isset($_POST['rwsc_focus_keyword'])) {
            $keyword = sanitize_text_field(trim($_POST['rwsc_focus_keyword']));
            if (!empty($keyword)) {
                update_post_meta($post_id, '_rwsc_focus_keyword', $keyword);
            } else {
                delete_post_meta($post_id, '_rwsc_focus_keyword');
            }
        }
    }
    
    /**
     * Cleanup post data
     */
    public function cleanup_post_data($post_id)
    {
        delete_post_meta($post_id, '_rwsc_focus_keyword');
        Engine\Engine::clear_cache($post_id);
    }
}