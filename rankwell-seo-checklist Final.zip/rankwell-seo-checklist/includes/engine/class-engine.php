<?php
/**
 * Rankwell SEO Checklist Engine - Main Class
 * 
 * @package Rankwell\SEO_Checklist\Engine
 * @since 1.3.0
 */

namespace Rankwell\SEO_Checklist\Engine;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Debug log to confirm file is loading
if (defined('WP_DEBUG') && WP_DEBUG) {
    error_log('RWSC Engine class file loaded');
}

class Engine extends Base
{

    /**
     * Run preflight check
     *
     * @param int    $post_id Post ID
     * @param string $keyword Focus keyword
     * @param string $content Post content
     * @return array Preflight results
     */
    public static function run_preflight($post_id, $keyword, $content)
    {
        $start_time = microtime(true);
        $memory_start = memory_get_usage();
        
        // Check cache first
        $cache_duration = get_option('rwsc_cache_duration', 300);
        if ($cache_duration > 0) {
            $cache_key = self::get_cache_key($post_id, $keyword, $content);
            $cached = self::get_cached_results($cache_key, $keyword, $content);
            
            if ($cached !== false) {
                $cached['cached'] = true;
                $cached['performance']['total_time'] = round((microtime(true) - $start_time) * 1000, 2) . 'ms';
                $cached['performance']['memory_used'] = round((memory_get_usage() - $memory_start) / 1024, 2) . 'KB';
                return $cached;
            }
        }
        
        // Get post data
        $post = get_post($post_id);
        if (!$post) {
            return [
                'error' => __('Invalid post', 'rankwell-seo-checklist'),
                'score' => 0,
                'checks' => [],
                'suggestions' => []
            ];
        }
        
        // Get SEO data from compatible plugins
        $seo_data = self::get_seo_data($post_id);
        
        // Get enabled checks
        $enabled_checks = get_option('rwsc_enabled_checks', []);
        
        // Run all checks
        $checks = [];
        
        // 1. Core SEO Checks
        $core_checks = Core_Checks::run_checks($post, $keyword, $content, $seo_data, $enabled_checks);
        $checks = array_merge($checks, $core_checks);
        
        // 2. Content Quality Checks (with Yoast-like features)
        $content_checks = Content_Quality::run_checks($post, $keyword, $content, $enabled_checks);
        $checks = array_merge($checks, $content_checks);
        
        // 3. Advanced Checks
        $advanced_checks = Advanced_Checks::run_checks($post, $keyword, $content, $enabled_checks);
        $checks = array_merge($checks, $advanced_checks);
        
        // Calculate score
        $score = self::calculate_score($checks);
        
        // Get suggestions
        $suggestions = self::get_suggestions($checks, $content, $keyword);
        
        // Clear large arrays
        unset($seo_data);
        
        // Prepare response
        $response = [
            'score' => $score,
            'checks' => $checks,
            'suggestions' => array_slice($suggestions, 0, 3),
            'performance' => [
                'total_time' => round((microtime(true) - $start_time) * 1000, 2) . 'ms',
                'memory_used' => round((memory_get_usage() - $memory_start) / 1024, 2) . 'KB',
                'checks_count' => count($checks)
            ],
            'keyword' => $keyword,
            'post_id' => $post_id,
            'content' => $content
        ];
        
        // Cache results if enabled
        if ($cache_duration > 0) {
            self::cache_results($response, $cache_duration);
        }
        
        return $response;
    }
}