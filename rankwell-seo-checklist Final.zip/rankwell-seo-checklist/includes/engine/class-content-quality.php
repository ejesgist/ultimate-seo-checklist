<?php
/**
 * Rankwell SEO Checklist Engine - Content Quality Checks with Yoast-like features
 * 
 * @package Rankwell\SEO_Checklist\Engine
 * @since 1.3.0
 */

namespace Rankwell\SEO_Checklist\Engine;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Content_Quality extends Base
{
    // Transition words list
    const TRANSITION_WORDS = [
        'however', 'therefore', 'consequently', 'as a result', 'for example',
        'for instance', 'specifically', 'in particular', 'similarly', 'likewise',
        'on the other hand', 'in contrast', 'nevertheless', 'nonetheless',
        'moreover', 'furthermore', 'additionally', 'in addition', 'first',
        'second', 'third', 'finally', 'in conclusion', 'to summarize',
        'thus', 'hence', 'accordingly', 'meanwhile', 'subsequently'
    ];
    
    // Passive voice indicators
    const PASSIVE_INDICATORS = [
        'is', 'are', 'was', 'were', 'be', 'being', 'been', 'am',
        'get', 'got', 'gets', 'gotten'
    ];
    
    // Common sentence starters to check for repetition
    const COMMON_STARTERS = [
        'the', 'a', 'an', 'this', 'that', 'these', 'those', 'i', 'we', 'you', 'he', 'she', 'it', 'they'
    ];
    
    /**
     * Run content quality checks with Yoast-like features
     *
     * @param WP_Post $post Post object
     * @param string  $keyword Focus keyword
     * @param string  $content Post content
     * @param array   $enabled_checks Enabled checks
     * @return array Content quality checks
     */
    public static function run_checks($post, $keyword, $content, $enabled_checks)
    {
        $checks = [];
        $clean_content = wp_strip_all_tags($content);
        $word_count = str_word_count($clean_content);
        $keyword_lower = strtolower($keyword);
        
        // 1. First Paragraph Keyword
        if (self::is_check_enabled('first_paragraph', $enabled_checks)) {
            $first_para = substr($clean_content, 0, 300);
            $has_first_para_keyword = stripos($first_para, $keyword) !== false;
            $checks[] = [
                'id' => 'first_paragraph',
                'label' => __('Keyword in First Paragraph', 'rankwell-seo-checklist'),
                'status' => $has_first_para_keyword ? 'pass' : 'warning',
                'description' => $has_first_para_keyword ? 
                    __('✓ Found in opening', 'rankwell-seo-checklist') : 
                    __('✗ Add to opening paragraph', 'rankwell-seo-checklist'),
                'weight' => 8
            ];
        }
        
        // 2. Headings Structure (Combine H2 and H3, require at least one H2)
        if (self::is_check_enabled('headings', $enabled_checks)) {
            $h1_count = preg_match_all('/<h1[^>]*>/i', $content);
            $h2_count = preg_match_all('/<h2[^>]*>/i', $content);
            $h3_count = preg_match_all('/<h3[^>]*>/i', $content);
            
            $total_h2h3 = $h2_count + $h3_count;
            $has_h2_keyword = preg_match('/<h2[^>]*>.*?' . preg_quote($keyword, '/') . '.*?<\/h2>/i', $content);
            $has_h2h3_keyword = $has_h2_keyword || preg_match('/<h3[^>]*>.*?' . preg_quote($keyword, '/') . '.*?<\/h3>/i', $content);
            
            $heading_status = 'pass';
            $heading_description = '';
            
            if ($h1_count > 1) {
                $heading_status = 'warning';
                $heading_description = __('Only one H1 recommended', 'rankwell-seo-checklist');
            } elseif ($h2_count < 1) {
                $heading_status = 'warning';
                $heading_description = __('Add at least one H2 heading', 'rankwell-seo-checklist');
            } elseif ($total_h2h3 < 2) {
                $heading_status = 'warning';
                $heading_description = __('Add more H2/H3 headings', 'rankwell-seo-checklist');
            } else {
                $heading_description = sprintf(__('%d H2, %d H3', 'rankwell-seo-checklist'), $h2_count, $h3_count);
                if ($has_h2h3_keyword) {
                    $heading_description .= ', ✓ has keyword';
                }
            }
            
            $checks[] = [
                'id' => 'headings',
                'label' => __('Headings (H2/H3)', 'rankwell-seo-checklist'),
                'status' => $heading_status,
                'description' => $heading_description,
                'weight' => 10
            ];
        }
        
        // 3. Image Alt Text
        if (self::is_check_enabled('image_alt', $enabled_checks)) {
            preg_match_all('/<img[^>]+alt=["\']([^"\']+)["\']/i', $content, $matches);
            $images_with_alt = 0;
            $images_with_keyword = 0;
            
            if (!empty($matches[1])) {
                $images_with_alt = count($matches[1]);
                foreach ($matches[1] as $alt) {
                    if (stripos($alt, $keyword) !== false) {
                        $images_with_keyword++;
                    }
                }
            }
            
            $image_status = ($images_with_alt > 0) ? 'pass' : 'warning';
            $checks[] = [
                'id' => 'image_alt',
                'label' => __('Image Alt Text', 'rankwell-seo-checklist'),
                'status' => $image_status,
                'description' => sprintf(__('%d images, %d with keyword', 'rankwell-seo-checklist'), 
                    $images_with_alt, 
                    $images_with_keyword),
                'weight' => 6
            ];
        }
        
        // 4. Keyword Bolded
        if (self::is_check_enabled('keyword_bolded', $enabled_checks)) {
            $is_bolded = preg_match('/<strong>.*?' . preg_quote($keyword, '/') . '.*?<\/strong>/i', $content) || 
                        preg_match('/<b>.*?' . preg_quote($keyword, '/') . '.*?<\/b>/i', $content);
            $checks[] = [
                'id' => 'keyword_bolded',
                'label' => __('Keyword Bolded', 'rankwell-seo-checklist'),
                'status' => $is_bolded ? 'pass' : 'warning',
                'description' => $is_bolded ? 
                    __('✓ Keyword is bolded', 'rankwell-seo-checklist') : 
                    __('✗ Consider bolding keyword', 'rankwell-seo-checklist'),
                'weight' => 4
            ];
        }
        
        // 5. Internal Links
        if (self::is_check_enabled('internal_links', $enabled_checks)) {
            $home_url = home_url();
            $internal_links = preg_match_all(
                '/<a[^>]+href=["\']' . preg_quote($home_url, '/') . '[^"\']*["\'][^>]*>/i',
                $content
            );
            
            $link_status = ($internal_links >= 2) ? 'pass' : 'warning';
            $checks[] = [
                'id' => 'internal_links',
                'label' => __('Internal Links (2+)', 'rankwell-seo-checklist'),
                'status' => $link_status,
                'description' => sprintf(__('%d internal links', 'rankwell-seo-checklist'), $internal_links),
                'weight' => 6
            ];
        }
        
        // 6. Readability (Yoast-like sentence length check)
        if (self::is_check_enabled('readability', $enabled_checks)) {
            $sentences = preg_split('/[.!?]+/', $clean_content, -1, PREG_SPLIT_NO_EMPTY);
            $sentence_count = count($sentences);
            
            if ($sentence_count > 0 && $word_count > 0) {
                $avg_sentence_length = $word_count / $sentence_count;
                
                // Count sentences over 20 words (Yoast standard)
                $long_sentences = 0;
                foreach ($sentences as $sentence) {
                    if (str_word_count($sentence) > 20) {
                        $long_sentences++;
                    }
                }
                $long_sentence_percentage = ($long_sentences / $sentence_count) * 100;
                
                $readability_status = 'pass';
                if ($long_sentence_percentage > 25) {
                    $readability_status = 'warning';
                } elseif ($long_sentence_percentage > 50) {
                    $readability_status = 'fail';
                }
                
                $checks[] = [
                    'id' => 'readability',
                    'label' => __('Readability & Sentence Length', 'rankwell-seo-checklist'),
                    'status' => $readability_status,
                    'description' => sprintf(__('%.1f avg words, %d%% long sentences', 'rankwell-seo-checklist'), 
                        $avg_sentence_length, 
                        round($long_sentence_percentage)),
                    'weight' => 8
                ];
            }
        }
        
        // 7. Content Paragraph Distribution
        if (self::is_check_enabled('paragraph_structure', $enabled_checks)) {
            $paragraph_data = self::analyze_paragraphs($content, $clean_content, $word_count);
            $checks[] = [
                'id' => 'paragraph_structure',
                'label' => __('Paragraph Structure', 'rankwell-seo-checklist'),
                'status' => $paragraph_data['status'],
                'description' => $paragraph_data['description'],
                'weight' => 6,
                'extra_data' => $paragraph_data
            ];
        }
        
        // 8. Content Has Conclusion
        if (self::is_check_enabled('content_conclusion', $enabled_checks)) {
            $has_conclusion = self::check_conclusion($content, $clean_content);
            $checks[] = [
                'id' => 'content_conclusion',
                'label' => __('Content Has Conclusion', 'rankwell-seo-checklist'),
                'status' => $has_conclusion ? 'pass' : 'info',
                'description' => $has_conclusion ? 
                    __('✓ Clear conclusion detected', 'rankwell-seo-checklist') : 
                    __('Consider adding a conclusion section', 'rankwell-seo-checklist'),
                'weight' => 4
            ];
        }
        
        // 9. Transition Words Usage (Enhanced Yoast-like)
        if (self::is_check_enabled('transition_words', $enabled_checks)) {
            $transition_data = self::analyze_transition_words($clean_content, $word_count);
            $checks[] = [
                'id' => 'transition_words',
                'label' => __('Transition Words', 'rankwell-seo-checklist'),
                'status' => $transition_data['status'],
                'description' => $transition_data['description'],
                'weight' => 5
            ];
        }
        
        // 10. Word Form Recognition (Keyword variations)
        if (self::is_check_enabled('word_form_recognition', $enabled_checks)) {
            $variation_data = self::check_keyword_variations($clean_content, $keyword);
            $checks[] = [
                'id' => 'word_form_recognition',
                'label' => __('Keyword Variations', 'rankwell-seo-checklist'),
                'status' => $variation_data['status'],
                'description' => $variation_data['description'],
                'weight' => 6
            ];
        }
        
        // 11. Passive Voice Detection (Yoast-like)
        if (self::is_check_enabled('passive_voice', $enabled_checks)) {
            $passive_data = self::check_passive_voice($clean_content);
            $checks[] = [
                'id' => 'passive_voice',
                'label' => __('Passive Voice', 'rankwell-seo-checklist'),
                'status' => $passive_data['status'],
                'description' => $passive_data['description'],
                'weight' => 5
            ];
        }
        
        // 12. Consecutive Sentences Check (Yoast-like)
        if (self::is_check_enabled('consecutive_sentences', $enabled_checks)) {
            $consecutive_data = self::check_consecutive_sentences($clean_content);
            $checks[] = [
                'id' => 'consecutive_sentences',
                'label' => __('Sentence Variety', 'rankwell-seo-checklist'),
                'status' => $consecutive_data['status'],
                'description' => $consecutive_data['description'],
                'weight' => 4
            ];
        }
        
        // 13. Subheading Distribution (Yoast-like)
        if (self::is_check_enabled('subheading_distribution', $enabled_checks)) {
            $subheading_data = self::check_subheading_distribution($content, $clean_content);
            $checks[] = [
                'id' => 'subheading_distribution',
                'label' => __('Subheading Distribution', 'rankwell-seo-checklist'),
                'status' => $subheading_data['status'],
                'description' => $subheading_data['description'],
                'weight' => 6
            ];
        }
        
        // 14. Keyword in H2/H3 (Enhanced check)
        if (self::is_check_enabled('keyword_in_subheadings', $enabled_checks)) {
            $subheading_keyword_data = self::check_keyword_in_subheadings($content, $keyword);
            $checks[] = [
                'id' => 'keyword_in_subheadings',
                'label' => __('Keyword in Subheadings', 'rankwell-seo-checklist'),
                'status' => $subheading_keyword_data['status'],
                'description' => $subheading_keyword_data['description'],
                'weight' => 7
            ];
        }
        
        // 15. Content Uniqueness Score
        if (self::is_check_enabled('content_uniqueness', $enabled_checks)) {
            $uniqueness_data = self::check_content_uniqueness($clean_content);
            $checks[] = [
                'id' => 'content_uniqueness',
                'label' => __('Content Uniqueness', 'rankwell-seo-checklist'),
                'status' => $uniqueness_data['status'],
                'description' => $uniqueness_data['description'],
                'weight' => 6
            ];
        }
        
        // 16. Emotional Tone Analysis
        if (self::is_check_enabled('emotional_tone', $enabled_checks)) {
            $emotional_tone_data = self::analyze_emotional_tone($clean_content);
            $checks[] = [
                'id' => 'emotional_tone',
                'label' => __('Emotional Tone', 'rankwell-seo-checklist'),
                'status' => $emotional_tone_data['status'],
                'description' => $emotional_tone_data['description'],
                'weight' => 4
            ];
        }
        
        // 17. Content Formatting Check
        if (self::is_check_enabled('content_formatting', $enabled_checks)) {
            $formatting_data = self::check_content_formatting($content);
            $checks[] = [
                'id' => 'content_formatting',
                'label' => __('Content Formatting', 'rankwell-seo-checklist'),
                'status' => $formatting_data['status'],
                'description' => $formatting_data['description'],
                'weight' => 4
            ];
        }
        
        // 18. Broken Content Check
        if (self::is_check_enabled('content_breaks', $enabled_checks)) {
            $breaks_data = self::check_content_breaks($content);
            $checks[] = [
                'id' => 'content_breaks',
                'label' => __('Content Breaks', 'rankwell-seo-checklist'),
                'status' => $breaks_data['status'],
                'description' => $breaks_data['description'],
                'weight' => 5
            ];
        }
        
        // 19. Related Posts Check
        if (self::is_check_enabled('related_posts', $enabled_checks)) {
            $related_data = self::check_related_posts($content, $post);
            $checks[] = [
                'id' => 'related_posts',
                'label' => __('Related Posts', 'rankwell-seo-checklist'),
                'status' => $related_data['status'],
                'description' => $related_data['description'],
                'weight' => 5
            ];
        }
        
        // 20. Consistency Check
        if (self::is_check_enabled('consistency_check', $enabled_checks)) {
            $consistency_data = self::check_consistency($clean_content, $keyword);
            $checks[] = [
                'id' => 'consistency_check',
                'label' => __('Consistency', 'rankwell-seo-checklist'),
                'status' => $consistency_data['status'],
                'description' => $consistency_data['description'],
                'weight' => 6
            ];
        }
        
        // 21. Opening Hook Check
        if (self::is_check_enabled('opening_hook', $enabled_checks)) {
            $hook_data = self::check_opening_hook($clean_content);
            $checks[] = [
                'id' => 'opening_hook',
                'label' => __('Opening Hook', 'rankwell-seo-checklist'),
                'status' => $hook_data['status'],
                'description' => $hook_data['description'],
                'weight' => 7
            ];
        }
        
        // 22. Scannability Score
        if (self::is_check_enabled('scannability_score', $enabled_checks)) {
            $scannability_data = self::check_scannability_score($content, $clean_content);
            $checks[] = [
                'id' => 'scannability_score',
                'label' => __('Scannability', 'rankwell-seo-checklist'),
                'status' => $scannability_data['status'],
                'description' => $scannability_data['description'],
                'weight' => 6
            ];
        }
        
        // 23. Jargon Detection
        if (self::is_check_enabled('jargon_detection', $enabled_checks)) {
            $jargon_data = self::detect_jargon($clean_content);
            $checks[] = [
                'id' => 'jargon_detection',
                'label' => __('Jargon Detection', 'rankwell-seo-checklist'),
                'status' => $jargon_data['status'],
                'description' => $jargon_data['description'],
                'weight' => 4
            ];
        }
        
        // 24. FAQ Anticipation
        if (self::is_check_enabled('faq_anticipation', $enabled_checks)) {
            $faq_data = self::check_faq_anticipation($clean_content, $keyword);
            $checks[] = [
                'id' => 'faq_anticipation',
                'label' => __('FAQ Anticipation', 'rankwell-seo-checklist'),
                'status' => $faq_data['status'],
                'description' => $faq_data['description'],
                'weight' => 5
            ];
        }
        
        // 25. Internal Link Suggestions
        if (self::is_check_enabled('internal_link_suggestions', $enabled_checks)) {
            $link_suggestions_data = self::suggest_internal_links($post, $clean_content);
            $checks[] = [
                'id' => 'internal_link_suggestions',
                'label' => __('Internal Link Suggestions', 'rankwell-seo-checklist'),
                'status' => $link_suggestions_data['status'],
                'description' => $link_suggestions_data['description'],
                'weight' => 5
            ];
        }
        
        return $checks;
    }
    
    /**
     * Analyze paragraphs structure
     */
    private static function analyze_paragraphs($content, $clean_content, $word_count)
    {
        // Better paragraph detection using HTML paragraph tags first
        $paragraph_count = 0;
        
        // Count <p> tags in content
        preg_match_all('/<p[^>]*>.*?<\/p>/si', $content, $p_matches);
        if (!empty($p_matches[0])) {
            $paragraph_count = count($p_matches[0]);
        } else {
            // Fallback to splitting by double newlines for plain text
            $paragraphs = preg_split('/\n\s*\n/', $clean_content);
            $paragraph_count = count(array_filter($paragraphs, function($para) {
                return str_word_count(trim($para)) > 10;
            }));
        }
        
        // Calculate average words per paragraph
        $avg_para_length = $paragraph_count > 0 ? $word_count / $paragraph_count : 0;
        
        // Count paragraphs over 150 words (Yoast standard)
        $long_paragraphs = 0;
        if (!empty($p_matches[0])) {
            foreach ($p_matches[0] as $paragraph) {
                $para_text = wp_strip_all_tags($paragraph);
                if (str_word_count($para_text) > 150) {
                    $long_paragraphs++;
                }
            }
        }
        
        // Determine status
        $para_status = 'pass';
        if ($paragraph_count > 0) {
            if ($avg_para_length > 200) {
                $para_status = 'warning';
            } elseif ($avg_para_length > 300) {
                $para_status = 'fail';
            }
            
            if ($long_paragraphs > 0) {
                $para_status = 'warning';
            }
        }
        
        $description = sprintf(__('%d paragraphs, avg %d words', 'rankwell-seo-checklist'), 
            $paragraph_count, 
            round($avg_para_length));
            
        if ($long_paragraphs > 0) {
            $description .= sprintf(__(', %d long paragraphs', 'rankwell-seo-checklist'), $long_paragraphs);
        }
        
        return [
            'status' => $para_status,
            'description' => $description,
            'paragraph_count' => $paragraph_count,
            'avg_para_length' => $avg_para_length,
            'long_paragraphs' => $long_paragraphs
        ];
    }
    
    /**
     * Check if content has a conclusion
     */
    private static function check_conclusion($content, $clean_content)
    {
        // Get paragraphs properly
        preg_match_all('/<p[^>]*>.*?<\/p>/si', $content, $p_matches);
        if (!empty($p_matches[0])) {
            $paragraphs = $p_matches[0];
        } else {
            $paragraphs = preg_split('/\n\s*\n/', $clean_content);
        }
        
        $last_paragraph = end($paragraphs);
        $has_conclusion = false;
        $conclusion_indicators = [
            'conclusion', 'summary', 'in summary', 'to sum up', 'finally', 
            'in conclusion', 'overall', 'to conclude', 'wrap up', 'key takeaways',
            'main points', 'to wrap up', 'in summary', 'ultimately'
        ];
        
        if ($last_paragraph) {
            $last_para_text = wp_strip_all_tags($last_paragraph);
            $last_para_lower = strtolower($last_para_text);
            foreach ($conclusion_indicators as $indicator) {
                if (strpos($last_para_lower, $indicator) !== false) {
                    $has_conclusion = true;
                    break;
                }
            }
            
            // Also check for summary-like language
            if (!$has_conclusion) {
                $summary_indicators = ['in short', 'all in all', 'to summarize', 'as weve seen'];
                foreach ($summary_indicators as $indicator) {
                    if (strpos($last_para_lower, $indicator) !== false) {
                        $has_conclusion = true;
                        break;
                    }
                }
            }
        }
        
        return $has_conclusion;
    }
    
    /**
     * Analyze transition words usage
     */
    private static function analyze_transition_words($clean_content, $word_count)
    {
        $transition_count = 0;
        $found_transitions = [];
        
        foreach (self::TRANSITION_WORDS as $word) {
            $pattern = '/\b' . preg_quote($word, '/') . '\b/i';
            if (preg_match_all($pattern, $clean_content, $matches)) {
                $transition_count += count($matches[0]);
                $found_transitions[] = $word;
            }
        }
        
        $transition_density = $word_count > 0 ? ($transition_count / $word_count) * 100 : 0;
        
        $transition_status = 'pass';
        $description = '';
        
        if ($transition_density < 0.5) {
            $transition_status = 'warning';
            $description = sprintf(__('Only %d transition words found (%.1f%%)', 'rankwell-seo-checklist'), 
                $transition_count, 
                $transition_density);
        } elseif ($transition_density > 2.5) {
            $transition_status = 'warning';
            $description = sprintf(__('%d transition words (%.1f%%) - may be excessive', 'rankwell-seo-checklist'), 
                $transition_count, 
                $transition_density);
        } else {
            $description = sprintf(__('%d transition words (%.1f%%) - good', 'rankwell-seo-checklist'), 
                $transition_count, 
                $transition_density);
        }
        
        return [
            'status' => $transition_status,
            'description' => $description,
            'count' => $transition_count,
            'density' => $transition_density,
            'found_words' => array_unique($found_transitions)
        ];
    }
    
    /**
     * Check for keyword variations (plurals, verb tenses, etc.)
     */
    private static function check_keyword_variations($clean_content, $keyword)
    {
        $keyword_lower = strtolower($keyword);
        $content_lower = strtolower($clean_content);
        
        // Get keyword stem (remove common endings)
        $stem = self::get_word_stem($keyword_lower);
        
        // Check for variations
        $variations_found = 0;
        $found_variations = [];
        
        // Common variations
        $possible_variations = [
            $keyword_lower, // Exact match
            $stem . 's',    // Plural
            $stem . 'es',   // Plural (es ending)
            $stem . 'ing',  // Present participle
            $stem . 'ed',   // Past tense
            $stem . 'er',   // Comparative
            $stem . 'est',  // Superlative
        ];
        
        foreach ($possible_variations as $variation) {
            if (strlen($variation) < 3) continue;
            
            $pattern = '/\b' . preg_quote($variation, '/') . '\b/';
            if (preg_match($pattern, $content_lower)) {
                $variations_found++;
                $found_variations[] = $variation;
            }
        }
        
        $status = ($variations_found >= 2) ? 'pass' : 'warning';
        
        $description = '';
        if ($variations_found >= 2) {
            $description = sprintf(__('✓ %d keyword variations found', 'rankwell-seo-checklist'), $variations_found);
        } else {
            $description = __('✗ Use more keyword variations (plurals, tenses)', 'rankwell-seo-checklist');
        }
        
        return [
            'status' => $status,
            'description' => $description,
            'variation_count' => $variations_found,
            'found_variations' => $found_variations
        ];
    }
    
    /**
     * Check for passive voice usage
     */
    private static function check_passive_voice($clean_content)
    {
        // Split into sentences
        $sentences = preg_split('/[.!?]+/', $clean_content, -1, PREG_SPLIT_NO_EMPTY);
        $sentence_count = count($sentences);
        
        if ($sentence_count === 0) {
            return [
                'status' => 'info',
                'description' => __('No sentences to analyze', 'rankwell-seo-checklist'),
                'passive_percentage' => 0,
                'passive_sentences' => 0
            ];
        }
        
        $passive_sentences = 0;
        $passive_sentence_list = [];
        
        foreach ($sentences as $sentence) {
            $sentence_lower = strtolower(trim($sentence));
            
            // Check for common passive voice patterns
            $is_passive = false;
            
            // Pattern 1: form of "to be" + past participle + "by"
            $pattern1 = '/(am|is|are|was|were|be|being|been)\s+\w+ed\s+by/i';
            if (preg_match($pattern1, $sentence_lower)) {
                $is_passive = true;
            }
            
            // Pattern 2: "get/got" + past participle
            if (!$is_passive) {
                $pattern2 = '/(get|got|gets|gotten)\s+\w+ed/i';
                if (preg_match($pattern2, $sentence_lower)) {
                    $is_passive = true;
                }
            }
            
            // Pattern 3: Common passive constructions
            if (!$is_passive) {
                $common_passive = [
                    'was made', 'were made', 'is made', 'are made',
                    'was given', 'were given', 'is given', 'are given',
                    'was taken', 'were taken', 'is taken', 'are taken',
                    'was found', 'were found', 'is found', 'are found',
                    'was seen', 'were seen', 'is seen', 'are seen'
                ];
                
                foreach ($common_passive as $phrase) {
                    if (strpos($sentence_lower, $phrase) !== false) {
                        $is_passive = true;
                        break;
                    }
                }
            }
            
            if ($is_passive) {
                $passive_sentences++;
                if (strlen($sentence) < 100) {
                    $passive_sentence_list[] = $sentence;
                }
            }
        }
        
        $passive_percentage = ($passive_sentences / $sentence_count) * 100;
        
        $status = 'pass';
        if ($passive_percentage > 10) {
            $status = 'warning';
        } elseif ($passive_percentage > 25) {
            $status = 'fail';
        }
        
        $description = '';
        if ($passive_percentage <= 10) {
            $description = sprintf(__('✓ Good: %.1f%% passive voice', 'rankwell-seo-checklist'), $passive_percentage);
        } else {
            $description = sprintf(__('⚠️ %.1f%% passive voice (aim for <10%%)', 'rankwell-seo-checklist'), $passive_percentage);
        }
        
        return [
            'status' => $status,
            'description' => $description,
            'passive_percentage' => $passive_percentage,
            'passive_sentences' => $passive_sentences,
            'total_sentences' => $sentence_count,
            'example_sentences' => array_slice($passive_sentence_list, 0, 3)
        ];
    }
    
    /**
     * Check for consecutive sentences starting with same word
     */
    private static function check_consecutive_sentences($clean_content)
    {
        $sentences = preg_split('/[.!?]+/', $clean_content, -1, PREG_SPLIT_NO_EMPTY);
        $sentence_count = count($sentences);
        
        if ($sentence_count < 3) {
            return [
                'status' => 'info',
                'description' => __('Not enough sentences to analyze', 'rankwell-seo-checklist'),
                'issues_found' => 0
            ];
        }
        
        $issues_found = 0;
        $issue_details = [];
        
        for ($i = 0; $i < $sentence_count - 2; $i++) {
            // Get first word of each sentence
            $first_words = [];
            for ($j = 0; $j < 3; $j++) {
                if (isset($sentences[$i + $j])) {
                    $sentence = trim($sentences[$i + $j]);
                    $words = explode(' ', $sentence);
                    $first_word = strtolower($words[0] ?? '');
                    // Remove punctuation
                    $first_word = preg_replace('/[^a-z]/', '', $first_word);
                    if (in_array($first_word, self::COMMON_STARTERS)) {
                        $first_words[] = $first_word;
                    }
                }
            }
            
            // Check if we have 3 consecutive sentences starting with the same common word
            if (count($first_words) === 3) {
                if ($first_words[0] === $first_words[1] && $first_words[1] === $first_words[2]) {
                    $issues_found++;
                    $issue_details[] = [
                        'position' => $i + 1,
                        'word' => $first_words[0],
                        'sentences' => [
                            substr($sentences[$i], 0, 50) . '...',
                            substr($sentences[$i + 1], 0, 50) . '...',
                            substr($sentences[$i + 2], 0, 50) . '...'
                        ]
                    ];
                }
            }
        }
        
        $status = ($issues_found === 0) ? 'pass' : 'warning';
        
        $description = '';
        if ($issues_found === 0) {
            $description = __('✓ Good sentence variety', 'rankwell-seo-checklist');
        } else {
            $description = sprintf(__('⚠️ %d repetitive sentence starts found', 'rankwell-seo-checklist'), $issues_found);
        }
        
        return [
            'status' => $status,
            'description' => $description,
            'issues_found' => $issues_found,
            'issue_details' => $issue_details
        ];
    }
    
    /**
     * Check subheading distribution (Yoast-like)
     */
    private static function check_subheading_distribution($content, $clean_content)
    {
        // Extract text between headings
        $heading_pattern = '/<(h[2-3])[^>]*>.*?<\/\1>/is';
        $content_without_tags = wp_strip_all_tags($content);
        
        // Split content by headings
        $sections = preg_split($heading_pattern, $content_without_tags);
        
        // Count words in each section
        $section_word_counts = [];
        $long_sections = 0;
        
        foreach ($sections as $section) {
            $word_count = str_word_count(trim($section));
            $section_word_counts[] = $word_count;
            if ($word_count > 300) {
                $long_sections++;
            }
        }
        
        // Check distribution
        $total_sections = count($section_word_counts);
        $avg_words_per_section = $total_sections > 0 ? array_sum($section_word_counts) / $total_sections : 0;
        
        $status = 'pass';
        if ($long_sections > 0) {
            $status = 'warning';
        }
        if ($long_sections > 2) {
            $status = 'fail';
        }
        
        $description = '';
        if ($long_sections === 0) {
            $description = __('✓ Good subheading distribution', 'rankwell-seo-checklist');
        } else {
            $description = sprintf(__('⚠️ %d long sections (>300 words)', 'rankwell-seo-checklist'), $long_sections);
        }
        
        return [
            'status' => $status,
            'description' => $description,
            'total_sections' => $total_sections,
            'long_sections' => $long_sections,
            'avg_words_per_section' => round($avg_words_per_section),
            'section_word_counts' => $section_word_counts
        ];
    }
    
    /**
     * Check for keyword in H2/H3 headings
     */
    private static function check_keyword_in_subheadings($content, $keyword)
    {
        // Find all H2 and H3 headings
        preg_match_all('/<(h[2-3])[^>]*>(.*?)<\/\1>/is', $content, $matches, PREG_SET_ORDER);
        
        $total_headings = count($matches);
        $headings_with_keyword = 0;
        $keyword_variations_found = 0;
        $heading_details = [];
        
        $keyword_lower = strtolower($keyword);
        $stem = self::get_word_stem($keyword_lower);
        
        foreach ($matches as $match) {
            $heading_level = $match[1];
            $heading_text = wp_strip_all_tags($match[2]);
            $heading_lower = strtolower($heading_text);
            
            // Check for exact keyword
            if (strpos($heading_lower, $keyword_lower) !== false) {
                $headings_with_keyword++;
                $keyword_variations_found++;
                $heading_details[] = [
                    'level' => $heading_level,
                    'text' => $heading_text,
                    'match_type' => 'exact'
                ];
            } else {
                // Check for variations
                $variations = [
                    $stem . 's',
                    $stem . 'es',
                    $stem . 'ing',
                    $stem . 'ed'
                ];
                
                foreach ($variations as $variation) {
                    if (strlen($variation) >= 3 && strpos($heading_lower, $variation) !== false) {
                        $keyword_variations_found++;
                        $heading_details[] = [
                            'level' => $heading_level,
                            'text' => $heading_text,
                            'match_type' => 'variation'
                        ];
                        break;
                    }
                }
            }
        }
        
        $status = 'pass';
        if ($total_headings === 0) {
            $status = 'warning';
            $description = __('No H2/H3 headings found', 'rankwell-seo-checklist');
        } elseif ($keyword_variations_found === 0) {
            $status = 'warning';
            $description = __('✗ Keyword not found in subheadings', 'rankwell-seo-checklist');
        } elseif ($keyword_variations_found === 1) {
            $status = 'pass';
            $description = __('✓ Keyword found in 1 subheading', 'rankwell-seo-checklist');
        } else {
            $status = 'pass';
            $description = sprintf(__('✓ Keyword found in %d subheadings', 'rankwell-seo-checklist'), $keyword_variations_found);
        }
        
        return [
            'status' => $status,
            'description' => $description,
            'total_headings' => $total_headings,
            'headings_with_keyword' => $headings_with_keyword,
            'keyword_variations_found' => $keyword_variations_found,
            'heading_details' => $heading_details
        ];
    }
    
    /**
     * Get word stem (basic stemmer)
     */
    protected static function get_word_stem($word)
    {
        $word = rtrim($word, 's');
        $word = rtrim($word, 'e');
        $word = rtrim($word, 'd');
        $word = rtrim($word, 'g');
        $word = rtrim($word, 'n');
        $word = rtrim($word, 'i');
        
        return $word;
    }
    
    /**
     * Check content uniqueness (basic heuristic without external API)
     */
    private static function check_content_uniqueness($clean_content)
    {
        $words = str_word_count(strtolower($clean_content), 1);
        $total_words = count($words);
        
        if ($total_words < 100) {
            return [
                'status' => 'info',
                'description' => __('Content too short for uniqueness analysis', 'rankwell-seo-checklist'),
                'score' => 0
            ];
        }
        
        // Calculate word frequency
        $word_frequency = array_count_values($words);
        
        // Find most common words
        arsort($word_frequency);
        $top_words = array_slice($word_frequency, 0, 10, true);
        
        // Calculate repetition score (lower is better)
        $repetition_score = 0;
        foreach ($top_words as $word => $count) {
            if (strlen($word) > 3) {
                $repetition_score += ($count / $total_words) * 100;
            }
        }
        
        // Calculate unique words percentage
        $unique_words = count($word_frequency);
        $uniqueness_percentage = ($unique_words / $total_words) * 100;
        
        // Basic heuristic scoring
        $score = 0;
        if ($uniqueness_percentage > 70) {
            $score = 90;
            $status = 'pass';
            $description = sprintf(__('✓ Good uniqueness (%.1f%% unique words)', 'rankwell-seo-checklist'), $uniqueness_percentage);
        } elseif ($uniqueness_percentage > 50) {
            $score = 70;
            $status = 'warning';
            $description = sprintf(__('⚠️ Moderate uniqueness (%.1f%% unique words)', 'rankwell-seo-checklist'), $uniqueness_percentage);
        } else {
            $score = 40;
            $status = 'warning';
            $description = sprintf(__('✗ Low uniqueness (%.1f%% unique words)', 'rankwell-seo-checklist'), $uniqueness_percentage);
        }
        
        // Check for excessive repetition
        if ($repetition_score > 15) {
            $score -= 20;
            $status = 'warning';
            $description .= __(' - Some word repetition', 'rankwell-seo-checklist');
        }
        
        return [
            'status' => $status,
            'description' => $description,
            'score' => $score,
            'uniqueness_percentage' => $uniqueness_percentage,
            'repetition_score' => $repetition_score,
            'total_words' => $total_words,
            'unique_words' => $unique_words
        ];
    }
    
    /**
     * Analyze emotional tone
     */
    private static function analyze_emotional_tone($clean_content)
    {
        $sentences = preg_split('/[.!?]+/', $clean_content, -1, PREG_SPLIT_NO_EMPTY);
        $sentence_count = count($sentences);
        
        if ($sentence_count < 3) {
            return [
                'status' => 'info',
                'description' => __('Not enough content for tone analysis', 'rankwell-seo-checklist'),
                'tone' => 'neutral'
            ];
        }
        
        // Emotional tone indicators
        $emotional_words = [
            'positive' => [
                'love', 'amazing', 'awesome', 'wonderful', 'excellent', 'fantastic',
                'great', 'perfect', 'happy', 'joy', 'exciting', 'inspiring',
                'beautiful', 'brilliant', 'success', 'win', 'achieve', 'hope',
                'confidence', 'proud', 'grateful', 'thankful', 'blessed'
            ],
            'negative' => [
                'hate', 'terrible', 'awful', 'horrible', 'bad', 'poor',
                'sad', 'angry', 'frustrated', 'disappointed', 'failure',
                'problem', 'issue', 'difficult', 'hard', 'struggle',
                'worry', 'anxious', 'scared', 'fear', 'danger', 'risk'
            ],
            'empathetic' => [
                'understand', 'feel', 'experience', 'share', 'connect',
                'support', 'help', 'guide', 'assist', 'care', 'concern',
                'relate', 'empathize', 'compassion', 'kindness'
            ],
            'authoritative' => [
                'proven', 'evidence', 'research', 'study', 'data',
                'expert', 'professional', 'certified', 'official',
                'guaranteed', 'verified', 'tested', 'approved'
            ]
        ];
        
        $tone_counts = [
            'positive' => 0,
            'negative' => 0,
            'empathetic' => 0,
            'authoritative' => 0
        ];
        
        $content_lower = strtolower($clean_content);
        
        // Count emotional words
        foreach ($emotional_words as $tone => $words) {
            foreach ($words as $word) {
                $pattern = '/\b' . preg_quote($word, '/') . '\b/';
                $tone_counts[$tone] += preg_match_all($pattern, $content_lower);
            }
        }
        
        // Determine dominant tone
        arsort($tone_counts);
        $dominant_tone = array_key_first($tone_counts);
        $dominant_count = $tone_counts[$dominant_tone];
        
        // Total emotional words
        $total_emotional_words = array_sum($tone_counts);
        $word_count = str_word_count($clean_content);
        $emotional_density = $word_count > 0 ? ($total_emotional_words / $word_count) * 100 : 0;
        
        $status = 'info';
        $description = '';
        
        if ($total_emotional_words === 0) {
            $description = __('Neutral tone detected', 'rankwell-seo-checklist');
        } elseif ($emotional_density < 0.5) {
            $status = 'warning';
            $description = sprintf(__('Low emotional tone (%.1f%%)', 'rankwell-seo-checklist'), $emotional_density);
        } else {
            $status = 'pass';
            $tone_labels = [
                'positive' => __('Positive', 'rankwell-seo-checklist'),
                'negative' => __('Negative', 'rankwell-seo-checklist'),
                'empathetic' => __('Empathetic', 'rankwell-seo-checklist'),
                'authoritative' => __('Authoritative', 'rankwell-seo-checklist')
            ];
            $description = sprintf(__('✓ %s tone detected', 'rankwell-seo-checklist'), 
                $tone_labels[$dominant_tone] ?? $dominant_tone);
        }
        
        return [
            'status' => $status,
            'description' => $description,
            'tone' => $dominant_tone,
            'emotional_density' => $emotional_density,
            'tone_counts' => $tone_counts,
            'total_emotional_words' => $total_emotional_words
        ];
    }
    
    /**
     * Check content formatting
     */
    private static function check_content_formatting($content)
    {
        // Check for over-formatting
        $bold_count = preg_match_all('/<(strong|b)>/i', $content);
        $italic_count = preg_match_all('/<(em|i)>/i', $content);
        $underline_count = preg_match_all('/<u>/i', $content);
        
        $word_count = str_word_count(wp_strip_all_tags($content));
        
        $formatting_ratio = $word_count > 0 ? (($bold_count + $italic_count + $underline_count) / $word_count) * 100 : 0;
        
        $status = 'pass';
        $description = __('✓ Good formatting balance', 'rankwell-seo-checklist');
        
        if ($formatting_ratio > 5) {
            $status = 'warning';
            $description = sprintf(__('⚠️ Heavy formatting (%.1f%%)', 'rankwell-seo-checklist'), $formatting_ratio);
        } elseif ($formatting_ratio < 0.5 && $word_count > 200) {
            $status = 'warning';
            $description = __('✗ Consider adding some formatting', 'rankwell-seo-checklist');
        }
        
        // Check formatting distribution
        $formatting_details = [];
        if ($bold_count > 0) $formatting_details[] = sprintf(__('%d bold', 'rankwell-seo-checklist'), $bold_count);
        if ($italic_count > 0) $formatting_details[] = sprintf(__('%d italic', 'rankwell-seo-checklist'), $italic_count);
        if ($underline_count > 0) $formatting_details[] = sprintf(__('%d underline', 'rankwell-seo-checklist'), $underline_count);
        
        if (!empty($formatting_details)) {
            $description .= ' (' . implode(', ', $formatting_details) . ')';
        }
        
        return [
            'status' => $status,
            'description' => $description,
            'formatting_ratio' => $formatting_ratio,
            'bold_count' => $bold_count,
            'italic_count' => $italic_count,
            'underline_count' => $underline_count
        ];
    }
    
    /**
     * Check for broken content
     */
    private static function check_content_breaks($content)
    {
        $issues = [];
        
        // Check for empty paragraphs
        $empty_paragraphs = preg_match_all('/<p>\s*<\/p>/i', $content);
        if ($empty_paragraphs > 0) {
            $issues[] = sprintf(__('%d empty paragraphs', 'rankwell-seo-checklist'), $empty_paragraphs);
        }
        
        // Check for broken shortcodes (basic check)
        $unclosed_shortcodes = preg_match_all('/\[[^\]]+$/', $content);
        if ($unclosed_shortcodes > 0) {
            $issues[] = sprintf(__('%d possible unclosed shortcodes', 'rankwell-seo-checklist'), $unclosed_shortcodes);
        }
        
        // Check for broken HTML tags (basic)
        $opening_tags = preg_match_all('/<(\w+)[^>]*>/', $content, $matches);
        $closing_tags = preg_match_all('/<\/\w+>/', $content);
        
        if ($opening_tags !== $closing_tags) {
            $issues[] = __('Possible HTML tag imbalance', 'rankwell-seo-checklist');
        }
        
        // Check for image placeholders
        $image_placeholders = preg_match_all('/<img[^>]*src=["\'][^"\']*["\'][^>]*>/i', $content, $img_matches);
        $broken_images = 0;
        
        if ($image_placeholders > 0) {
            foreach ($img_matches[0] as $img_tag) {
                if (strpos($img_tag, 'src=""') !== false || 
                    strpos($img_tag, "src=''") !== false ||
                    preg_match('/src=["\'](placeholder|default|broken)/i', $img_tag)) {
                    $broken_images++;
                }
            }
            
            if ($broken_images > 0) {
                $issues[] = sprintf(__('%d possible broken images', 'rankwell-seo-checklist'), $broken_images);
            }
        }
        
        $status = count($issues) === 0 ? 'pass' : 'warning';
        
        // Build description without translating dynamic content
        if (count($issues) === 0) {
            $description = __('✓ No content breaks detected', 'rankwell-seo-checklist');
        } else {
            $description = '⚠️ ' . implode(', ', $issues);
        }
        
        return [
            'status' => $status,
            'description' => $description,
            'issues' => $issues,
            'empty_paragraphs' => $empty_paragraphs,
            'unclosed_shortcodes' => $unclosed_shortcodes,
            'tag_imbalance' => $opening_tags !== $closing_tags,
            'broken_images' => $broken_images
        ];
    }
    
    /**
     * Check for related posts/content mentions
     */
    private static function check_related_posts($content, $post)
    {
        // Get current post category/tags
        $categories = wp_get_post_categories($post->ID, ['fields' => 'names']);
        $tags = wp_get_post_tags($post->ID, ['fields' => 'names']);
        
        // Check for internal links to other posts
        $home_url = home_url();
        $internal_links = preg_match_all(
            '/<a[^>]+href=["\']' . preg_quote($home_url, '/') . '[^"\']*["\'][^>]*>/i',
            $content
        );
        
        // Check for mentions of related topics (basic)
        $related_terms = array_merge($categories, $tags);
        $content_lower = strtolower(wp_strip_all_tags($content));
        
        $related_mentions = 0;
        foreach ($related_terms as $term) {
            if (strlen($term) > 3) {
                $term_lower = strtolower($term);
                if (strpos($content_lower, $term_lower) !== false) {
                    $related_mentions++;
                }
            }
        }
        
        $status = 'info';
        $description = '';
        
        if ($internal_links >= 2 && $related_mentions >= 2) {
            $status = 'pass';
            $description = sprintf(__('%d internal links, %d related mentions', 'rankwell-seo-checklist'), 
                $internal_links, $related_mentions);
        } elseif ($internal_links >= 1 || $related_mentions >= 1) {
            $status = 'warning';
            $description = sprintf(__('%d internal links, %d related mentions', 'rankwell-seo-checklist'), 
                $internal_links, $related_mentions);
        } else {
            $description = __('Consider adding internal links to related content', 'rankwell-seo-checklist');
        }
        
        return [
            'status' => $status,
            'description' => $description,
            'internal_links' => $internal_links,
            'related_mentions' => $related_mentions,
            'categories' => $categories,
            'tags' => $tags
        ];
    }
    
    /**
     * Check terminology consistency
     */
    private static function check_consistency($clean_content, $keyword)
    {
        $words = str_word_count(strtolower($clean_content), 1);
        $word_frequency = array_count_values($words);
        
        // Look for similar/related terms that might indicate inconsistency
        $inconsistency_patterns = [
            // Common inconsistencies
            'website' => ['site', 'webpage', 'page'],
            'blog' => ['article', 'post', 'content'],
            'guide' => ['tutorial', 'how-to', 'manual'],
            'tips' => ['advice', 'suggestions', 'recommendations'],
            'tools' => ['software', 'apps', 'applications'],
            'free' => ['complimentary', 'no-cost', 'gratis'],
            'buy' => ['purchase', 'acquire', 'get'],
            'learn' => ['study', 'understand', 'master']
        ];
        
        $inconsistencies_found = [];
        
        foreach ($inconsistency_patterns as $main_term => $alternatives) {
            $main_count = $word_frequency[$main_term] ?? 0;
            $alternative_count = 0;
            
            foreach ($alternatives as $alternative) {
                $alternative_count += $word_frequency[$alternative] ?? 0;
            }
            
            if ($main_count > 0 && $alternative_count > 0) {
                $inconsistencies_found[] = $main_term;
            }
        }
        
        // Check keyword variations consistency
        $keyword_lower = strtolower($keyword);
        $keyword_stem = self::get_word_stem($keyword_lower);
        
        $keyword_variations = [
            $keyword_lower,
            $keyword_stem . 's',
            $keyword_stem . 'es',
            $keyword_stem . 'ing',
            $keyword_stem . 'ed'
        ];
        
        $keyword_usage = 0;
        foreach ($keyword_variations as $variation) {
            if (isset($word_frequency[$variation])) {
                $keyword_usage += $word_frequency[$variation];
            }
        }
        
        $status = 'pass';
        $description = __('✓ Consistent terminology', 'rankwell-seo-checklist');
        
        if (!empty($inconsistencies_found)) {
            $status = 'warning';
            $description = sprintf(__('%d potential inconsistencies', 'rankwell-seo-checklist'), 
                count($inconsistencies_found));
        }
        
        if ($keyword_usage === 0 && strlen($keyword) > 3) {
            $status = 'warning';
            $description = __('✗ Keyword not used consistently', 'rankwell-seo-checklist');
        }
        
        return [
            'status' => $status,
            'description' => $description,
            'inconsistencies_found' => $inconsistencies_found,
            'keyword_usage' => $keyword_usage,
            'word_frequency' => $word_frequency
        ];
    }
    
    /**
     * Check opening hook quality
     */
    private static function check_opening_hook($clean_content)
    {
        // Get first 150 characters (opening hook)
        $opening = substr($clean_content, 0, 150);
        $opening_words = str_word_count($opening);
        
        if ($opening_words < 10) {
            return [
                'status' => 'warning',
                'description' => __('Opening too short for hook analysis', 'rankwell-seo-checklist'),
                'opening_length' => $opening_words
            ];
        }
        
        // Check for engaging elements in opening
        $engaging_elements = [
            'question' => preg_match('/^(Who|What|When|Where|Why|How|Are|Do|Can|Will)\b/i', $opening) ? 1 : 0,
            'statistic' => preg_match('/\d+%/i', $opening) || preg_match('/\d+ of/i', $opening) ? 1 : 0,
            'story' => preg_match('/(I|We|You|He|She|They)\s+(recently|once|always|never)/i', $opening) ? 1 : 0,
            'problem' => preg_match('/(struggle|problem|challenge|issue|difficulty|pain)/i', $opening) ? 1 : 0,
            'benefit' => preg_match('/(learn|discover|find out|uncover|reveal)/i', $opening) ? 1 : 0,
            'urgency' => preg_match('/(today|now|immediate|quick|fast|instant)/i', $opening) ? 1 : 0
        ];
        
        $engagement_score = array_sum($engaging_elements);
        
        $status = 'warning';
        $description = __('✗ Weak opening hook', 'rankwell-seo-checklist');
        
        if ($engagement_score >= 3) {
            $status = 'pass';
            $description = __('✓ Strong opening hook detected', 'rankwell-seo-checklist');
        } elseif ($engagement_score >= 2) {
            $status = 'warning';
            $description = __('⚠️ Moderate opening hook', 'rankwell-seo-checklist');
        }
        
        // Add details about engaging elements found
        $elements_found = [];
        foreach ($engaging_elements as $element => $found) {
            if ($found) {
                $elements_found[] = $element;
            }
        }
        
        if (!empty($elements_found)) {
            $description .= ' (' . implode(', ', $elements_found) . ')';
        }
        
        return [
            'status' => $status,
            'description' => $description,
            'engagement_score' => $engagement_score,
            'engaging_elements' => $engaging_elements,
            'elements_found' => $elements_found,
            'opening_length' => $opening_words
        ];
    }
    
    /**
     * Check scannability score
     */
    private static function check_scannability_score($content, $clean_content)
    {
        $word_count = str_word_count($clean_content);
        
        // Count scannable elements
        $headings = preg_match_all('/<h[2-6][^>]*>/i', $content);
        $lists = preg_match_all('/<(ul|ol)>/i', $content);
        $list_items = preg_match_all('/<li>/i', $content);
        $tables = preg_match_all('/<table[^>]*>/i', $content);
        $images = preg_match_all('/<img[^>]*>/i', $content);
        $blockquotes = preg_match_all('/<blockquote[^>]*>/i', $content);
        
        // Calculate scannability score
        $scannable_elements = $headings + $lists + $tables + $images + $blockquotes;
        $scannability_ratio = $word_count > 0 ? ($scannable_elements / $word_count) * 1000 : 0;
        
        $status = 'pass';
        $description = __('✓ Good scannability', 'rankwell-seo-checklist');
        
        if ($scannability_ratio < 5 && $word_count > 500) {
            $status = 'warning';
            $description = sprintf(__('⚠️ Low scannability (%.1f elements per 1000 words)', 'rankwell-seo-checklist'), $scannability_ratio);
        } elseif ($scannability_ratio > 20) {
            $status = 'warning';
            $description = sprintf(__('⚠️ Possibly over-formatted (%.1f elements per 1000 words)', 'rankwell-seo-checklist'), $scannability_ratio);
        }
        
        // Add element breakdown
        $element_details = [];
        if ($headings > 0) $element_details[] = sprintf(__('%d headings', 'rankwell-seo-checklist'), $headings);
        if ($lists > 0) $element_details[] = sprintf(__('%d lists', 'rankwell-seo-checklist'), $lists);
        if ($list_items > 0) $element_details[] = sprintf(__('%d list items', 'rankwell-seo-checklist'), $list_items);
        if ($tables > 0) $element_details[] = sprintf(__('%d tables', 'rankwell-seo-checklist'), $tables);
        if ($images > 0) $element_details[] = sprintf(__('%d images', 'rankwell-seo-checklist'), $images);
        if ($blockquotes > 0) $element_details[] = sprintf(__('%d quotes', 'rankwell-seo-checklist'), $blockquotes);
        
        if (!empty($element_details)) {
            $description .= ' (' . implode(', ', $element_details) . ')';
        }
        
        return [
            'status' => $status,
            'description' => $description,
            'scannability_ratio' => $scannability_ratio,
            'scannable_elements' => $scannable_elements,
            'headings' => $headings,
            'lists' => $lists,
            'list_items' => $list_items,
            'tables' => $tables,
            'images' => $images,
            'blockquotes' => $blockquotes
        ];
    }
    
    /**
     * Detect jargon/technical terms
     */
    private static function detect_jargon($clean_content)
    {
        // Common jargon/technical terms by category
        $jargon_terms = [
            'technical' => [
                'algorithm', 'api', 'bandwidth', 'cache', 'cms', 'css', 'database',
                'framework', 'html', 'http', 'https', 'javascript', 'json', 'php',
                'protocol', 'query', 'responsive', 'schema', 'script', 'server',
                'ssl', 'ssl', 'template', 'url', 'ux', 'xml'
            ],
            'business' => [
                'benchmark', 'best practice', 'bottom line', 'core competency',
                'disrupt', 'granular', 'ideate', 'incentivize', 'key takeaway',
                'leverage', 'low-hanging fruit', 'mission-critical', 'onboarding',
                'paradigm', 'proactive', 'scalable', 'synergy', 'value-added'
            ],
            'academic' => [
                'aforementioned', 'caveat', 'conversely', 'eponymous', 'ergo',
                'henceforth', 'heretofore', 'ipso facto', 'per se', 'prima facie',
                'qua', 'sine qua non', 'vis-à-vis'
            ]
        ];
        
        $content_lower = strtolower($clean_content);
        $word_count = str_word_count($clean_content);
        $jargon_counts = [];
        $total_jargon = 0;
        
        foreach ($jargon_terms as $category => $terms) {
            $category_count = 0;
            foreach ($terms as $term) {
                $pattern = '/\b' . preg_quote($term, '/') . '\b/';
                $category_count += preg_match_all($pattern, $content_lower);
            }
            $jargon_counts[$category] = $category_count;
            $total_jargon += $category_count;
        }
        
        $jargon_density = $word_count > 0 ? ($total_jargon / $word_count) * 100 : 0;
        
        $status = 'info';
        $description = __('✓ Accessible language', 'rankwell-seo-checklist');
        
        if ($jargon_density > 1.5) {
            $status = 'warning';
            $description = sprintf(__('⚠️ High jargon density (%.1f%%)', 'rankwell-seo-checklist'), $jargon_density);
        } elseif ($total_jargon > 5) {
            $status = 'warning';
            $description = sprintf(__('%d jargon terms detected', 'rankwell-seo-checklist'), $total_jargon);
        }
        
        // Add category breakdown if jargon found
        if ($total_jargon > 0) {
            $category_details = [];
            foreach ($jargon_counts as $category => $count) {
                if ($count > 0) {
                    $category_labels = [
                        'technical' => __('technical', 'rankwell-seo-checklist'),
                        'business' => __('business', 'rankwell-seo-checklist'),
                        'academic' => __('academic', 'rankwell-seo-checklist')
                    ];
                    $category_details[] = sprintf(__('%d %s', 'rankwell-seo-checklist'), 
                        $count, $category_labels[$category] ?? $category);
                }
            }
            if (!empty($category_details)) {
                $description .= ' (' . implode(', ', $category_details) . ')';
            }
        }
        
        return [
            'status' => $status,
            'description' => $description,
            'jargon_density' => $jargon_density,
            'total_jargon' => $total_jargon,
            'jargon_counts' => $jargon_counts,
            'word_count' => $word_count
        ];
    }
    
    /**
     * Check for FAQ anticipation
     */
    private static function check_faq_anticipation($clean_content, $keyword)
    {
        $sentences = preg_split('/[.!?]+/', $clean_content, -1, PREG_SPLIT_NO_EMPTY);
        $sentence_count = count($sentences);
        
        if ($sentence_count < 5) {
            return [
                'status' => 'info',
                'description' => __('Not enough content for FAQ analysis', 'rankwell-seo-checklist'),
                'question_count' => 0
            ];
        }
        
        // Look for question patterns
        $question_patterns = [
            'direct' => '/(Who|What|When|Where|Why|How|Are|Do|Does|Can|Will|Is|Should)\b.*?\?/i',
            'common' => '/(question|wonder|ask|curious|think about|consider)/i',
            'solution' => '/(solve|answer|address|handle|deal with|tackle)/i'
        ];
        
        $question_sentences = 0;
        $question_types = [];
        
        foreach ($sentences as $sentence) {
            $sentence_trimmed = trim($sentence);
            
            // Direct questions (ends with ?)
            if (substr($sentence_trimmed, -1) === '?') {
                $question_sentences++;
                $question_types['direct'] = ($question_types['direct'] ?? 0) + 1;
            }
            // Contains question words or patterns
            else {
                foreach ($question_patterns as $type => $pattern) {
                    if (preg_match($pattern, $sentence_trimmed)) {
                        $question_sentences++;
                        $question_types[$type] = ($question_types[$type] ?? 0) + 1;
                        break;
                    }
                }
            }
        }
        
        $question_ratio = $sentence_count > 0 ? ($question_sentences / $sentence_count) * 100 : 0;
        
        $status = 'info';
        $description = __('✗ No FAQ anticipation detected', 'rankwell-seo-checklist');
        
        if ($question_ratio > 5) {
            $status = 'pass';
            $description = sprintf(__('✓ Good FAQ anticipation (%.1f%% questions)', 'rankwell-seo-checklist'), $question_ratio);
        } elseif ($question_sentences > 0) {
            $status = 'warning';
            $description = sprintf(__('⚠️ Some FAQ anticipation (%d questions)', 'rankwell-seo-checklist'), $question_sentences);
        }
        
        return [
            'status' => $status,
            'description' => $description,
            'question_ratio' => $question_ratio,
            'question_sentences' => $question_sentences,
            'sentence_count' => $sentence_count,
            'question_types' => $question_types
        ];
    }
    
    /**
     * Suggest internal links (basic heuristic)
     */
    private static function suggest_internal_links($post, $clean_content)
    {
        // Get current post's terms
        $categories = wp_get_post_categories($post->ID, ['fields' => 'names']);
        $tags = wp_get_post_tags($post->ID, ['fields' => 'names']);
        
        // Get all terms
        $all_terms = array_merge($categories, $tags);
        
        // Count existing internal links
        $home_url = home_url();
        $existing_links = preg_match_all(
            '/<a[^>]+href=["\']' . preg_quote($home_url, '/') . '[^"\']*["\'][^>]*>/i',
            wp_strip_all_tags($post->post_content)
        );
        
        // Analyze content for potential link opportunities
        $content_lower = strtolower($clean_content);
        $potential_links = 0;
        
        foreach ($all_terms as $term) {
            if (strlen($term) > 3) {
                $term_lower = strtolower($term);
                if (strpos($content_lower, $term_lower) !== false) {
                    $potential_links++;
                }
            }
        }
        
        $status = 'info';
        $description = '';
        
        if ($existing_links >= 3) {
            $status = 'pass';
            $description = sprintf(__('✓ %d internal links found', 'rankwell-seo-checklist'), $existing_links);
        } elseif ($existing_links > 0) {
            $status = 'warning';
            $description = sprintf(__('⚠️ Only %d internal links (aim for 3+)', 'rankwell-seo-checklist'), $existing_links);
        } else {
            $description = __('✗ No internal links found', 'rankwell-seo-checklist');
        }
        
        // Add potential link suggestions if few links exist
        if ($existing_links < 3 && $potential_links > 0) {
            $description .= sprintf(__(' (%d potential link opportunities)', 'rankwell-seo-checklist'), $potential_links);
        }
        
        return [
            'status' => $status,
            'description' => $description,
            'existing_links' => $existing_links,
            'potential_links' => $potential_links,
            'categories' => $categories,
            'tags' => $tags,
            'total_terms' => count($all_terms)
        ];
    }
}