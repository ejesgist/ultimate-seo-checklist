<?php
/**
 * Rankwell SEO Checklist Engine - Base Class
 * 
 * @package Rankwell\SEO_Checklist\Engine
 * @since 1.3.0
 */

namespace Rankwell\SEO_Checklist\Engine;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Base
{
    // SEO plugin compatibility constants
    const SEO_PLUGINS = [
        'yoast' => [
            'title' => '_yoast_wpseo_title',
            'description' => '_yoast_wpseo_metadesc',
            'focus_keyword' => '_yoast_wpseo_focuskw'
        ],
        'rankmath' => [
            'title' => '_rank_math_title',
            'description' => '_rank_math_description',
            'focus_keyword' => '_rank_math_focus_keyword'
        ],
        'aioseo' => [
            'title' => '_aioseo_title',
            'description' => '_aioseo_description',
            'focus_keyword' => '_aioseo_keywords'
        ],
        'seopress' => [
            'title' => '_seopress_titles_title',
            'description' => '_seopress_titles_desc',
            'focus_keyword' => '_seopress_analysis_target_kw'
        ],
        'the_seo_framework' => [
            'title' => '_genesis_title',
            'description' => '_genesis_description'
        ]
    ];
    
    /**
     * Check if a specific check is enabled
     *
     * @param string $check_id Check ID
     * @param array  $enabled_checks Enabled checks array
     * @return bool Whether the check is enabled
     */
    protected static function is_check_enabled($check_id, $enabled_checks)
    {
        // If no enabled checks specified, run all
        if (empty($enabled_checks)) {
            return true;
        }
        
        return isset($enabled_checks[$check_id]) && $enabled_checks[$check_id];
    }
    
    /**
     * Calculate overall score
     *
     * @param array $checks Array of checks
     * @return int Score 0-100
     */
    protected static function calculate_score($checks)
    {
        $total_weight = 0;
        $weighted_score = 0;
        
        foreach ($checks as $check) {
            $weight = $check['weight'] ?? 1;
            $total_weight += $weight;
            
            switch ($check['status']) {
                case 'pass':
                    $weighted_score += $weight;
                    break;
                case 'warning':
                    $weighted_score += $weight * 0.5;
                    break;
                case 'info':
                    $weighted_score += $weight * 0.8;
                    break;
                case 'fail':
                    // No points for fails
                    break;
            }
        }
        
        if ($total_weight === 0) {
            return 0;
        }
        
        return round(($weighted_score / $total_weight) * 100);
    }
    
    /**
     * Get SEO data from compatible plugins
     *
     * @param int $post_id Post ID
     * @return array SEO data
     */
    protected static function get_seo_data($post_id)
    {
        $data = [
            'title' => '',
            'description' => '',
            'focus_keyword' => ''
        ];
        
        $compatibility_mode = get_option('rwsc_compatibility_mode', 1);
        
        if (!$compatibility_mode) {
            return $data;
        }
        
        // Check each SEO plugin
        foreach (self::SEO_PLUGINS as $plugin => $meta_keys) {
            if (isset($meta_keys['title'])) {
                $title = get_post_meta($post_id, $meta_keys['title'], true);
                if (!empty($title)) {
                    $data['title'] = $title;
                    break;
                }
            }
        }
        
        // Get description
        foreach (self::SEO_PLUGINS as $plugin => $meta_keys) {
            if (isset($meta_keys['description'])) {
                $desc = get_post_meta($post_id, $meta_keys['description'], true);
                if (!empty($desc)) {
                    $data['description'] = $desc;
                    break;
                }
            }
        }
        
        return $data;
    }
    
    /**
     * Get cache key
     *
     * @param int    $post_id Post ID
     * @param string $keyword Focus keyword
     * @param string $content Post content
     * @return string Cache key
     */
    protected static function get_cache_key($post_id, $keyword, $content)
    {
        return 'rwsc_' . $post_id . '_' . md5($keyword . $content);
    }
    
    /**
     * Get cached results
     *
     * @param string $cache_key Cache key
     * @param string $keyword Focus keyword
     * @param string $content Post content
     * @return mixed|false Cached results or false
     */
    protected static function get_cached_results($cache_key, $keyword, $content)
    {
        global $wpdb;
        
        $table = $wpdb->prefix . RWSC_CACHE_TABLE;
        
        // First check if table exists
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table'");
        if (!$table_exists) {
            return false;
        }
        
        $result = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT results FROM {$table} WHERE keyword_hash = %s AND content_hash = %s AND created_at > DATE_SUB(NOW(), INTERVAL %d SECOND)",
                md5($keyword),
                md5($content),
                get_option('rwsc_cache_duration', 300)
            )
        );
        
        if ($result) {
            return maybe_unserialize($result);
        }
        
        return false;
    }
    
    /**
     * Cache results
     *
     * @param array $data Data to cache
     * @param int   $duration Cache duration in seconds
     * @return void
     */
    protected static function cache_results($data, $duration)
    {
        global $wpdb;
        
        $table = $wpdb->prefix . RWSC_CACHE_TABLE;
        
        // Check if table exists
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table'");
        if (!$table_exists) {
            return;
        }
        
        // Clean old cache entries
        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$table} WHERE created_at < DATE_SUB(NOW(), INTERVAL %d SECOND)",
                $duration * 2
            )
        );
        
        // Insert new cache
        $wpdb->insert(
            $table,
            [
                'post_id' => $data['post_id'] ?? 0,
                'keyword_hash' => md5($data['keyword'] ?? ''),
                'content_hash' => md5($data['content'] ?? ''),
                'results' => maybe_serialize($data)
            ],
            ['%d', '%s', '%s', '%s']
        );
    }
    
    /**
     * Clear cache for post
     *
     * @param int $post_id Post ID
     * @return void
     */
    public static function clear_cache($post_id)
    {
        global $wpdb;
        
        $table = $wpdb->prefix . RWSC_CACHE_TABLE;
        
        // Check if table exists
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table'");
        if ($table_exists) {
            $wpdb->delete($table, ['post_id' => $post_id], ['%d']);
        }
        
        // Also clear transients
        delete_transient('rwsc_preflight_' . $post_id);
    }
    
    /**
     * Helper: Find power words in text
     *
     * @param string $text Text to analyze
     * @return array Power words found
     */
    protected static function find_power_words($text)
    {
        $found = [];
        $categories = [];
        $text_lower = strtolower($text);
        
        $power_words = [
            'amazing', 'awesome', 'best', 'brilliant', 'complete', 'comprehensive', 'critical',
            'definitive', 'essential', 'excellent', 'exclusive', 'expert', 'extraordinary',
            'fantastic', 'free', 'full', 'great', 'guaranteed', 'instant', 'limited', 'massive',
            'maximum', 'mind-blowing', 'must-have', 'powerful', 'proven', 'revolutionary',
            'secret', 'simple', 'smart', 'special', 'successful', 'super', 'top', 'ultimate',
            'unique', 'unlimited', 'urgent', 'valuable', 'verified', 'winning'
        ];
        
        $power_word_categories = [
            'emotional' => ['amazing', 'awesome', 'fantastic', 'incredible', 'mind-blowing', 'wonderful'],
            'urgency' => ['urgent', 'limited', 'now', 'immediately', 'instant', 'last chance'],
            'exclusivity' => ['exclusive', 'secret', 'hidden', 'revealed', 'confidential', 'insider'],
            'authority' => ['proven', 'expert', 'certified', 'professional', 'official', 'verified'],
            'benefits' => ['free', 'guaranteed', 'easy', 'simple', 'fast', 'effective'],
            'numbers' => ['ultimate', 'complete', 'full', 'maximum', 'top', 'best'],
            'scarcity' => ['limited', 'rare', 'scarce', 'exclusive', 'last', 'final'],
            'curiosity' => ['secret', 'revealed', 'exposed', 'truth', 'hidden', 'confidential']
        ];
        
        foreach ($power_words as $word) {
            if (strpos($word, ' ') !== false) {
                if (stripos($text_lower, $word) !== false) {
                    $found[] = $word;
                    // Categorize
                    foreach ($power_word_categories as $category => $words) {
                        if (in_array($word, $words)) {
                            $categories[$category] = ($categories[$category] ?? 0) + 1;
                        }
                    }
                }
            } else {
                if (preg_match('/\b' . preg_quote($word, '/') . '\b/', $text_lower)) {
                    $found[] = $word;
                    // Categorize
                    foreach ($power_word_categories as $category => $words) {
                        if (in_array($word, $words)) {
                            $categories[$category] = ($categories[$category] ?? 0) + 1;
                        }
                    }
                }
            }
        }
        
        return [
            'words' => array_unique($found),
            'categories' => $categories,
            'count' => count(array_unique($found))
        ];
    }
    
    /**
     * Helper: Find uncommon words in text
     *
     * @param string $text Text to analyze
     * @return array Uncommon words found
     */
    protected static function find_uncommon_words($text)
    {
        $found = [];
        $text_lower = strtolower($text);
        $words = str_word_count($text_lower, 1);
        
        $uncommon_words = [
            'heart', 'actually', 'its', 'found', 'ways', 'time', 'life', 'year',
            'made', 'more', 'photos', 'down', 'happened', 'makes', 'beautiful',
            'right', 'social', 'need', 'good', 'seen', 'want', 'thing', 'here',
            'girl', 'love', 'being', 'media', 'old', 'youll', 'now', 'look', 'best',
            'man', 'dog', 'baby', 'new', 'something', 'see', 'guy', 'facebook',
            'better', 'never', 'first', 'little', 'think', 'really', 'mind',
            'awesome', 'watch', 'valentines', 'make', 'out', 'boy', 'one', 'video',
            'way', 'years', 'people', 'reasons', 'world', 'know', 'from the'
        ];
        
        foreach ($uncommon_words as $word) {
            if (in_array($word, $words)) {
                $found[] = $word;
            }
        }
        
        return array_unique($found);
    }
    
    /**
     * Helper: Analyze sentiment in text
     *
     * @param string $text Text to analyze
     * @return array Sentiment analysis results
     */
    protected static function analyze_sentiment($text)
    {
        $text_lower = strtolower($text);
        $positive_found = [];
        $negative_found = [];
        
        $positive_words = [
            'amazing', 'awesome', 'best', 'better', 'brilliant', 'easy', 'excellent',
            'fantastic', 'free', 'good', 'great', 'helpful', 'improved', 'perfect',
            'positive', 'powerful', 'successful', 'super', 'top', 'ultimate', 'winning',
            'milestone', 'victory', 'breakthrough', 'inspiring', 'heroic', 'celebrated',
            'relief', 'energy', 'rejuvenated', 'healing', 'balanced', 'strong', 'healthy',
            'guaranteed', 'easy', 'simple', 'fast', 'perfect', 'brilliant', 'success',
            'effortless', 'genius'
        ];
        
        $negative_words = [
            'avoid', 'bad', 'critical', 'dangerous', 'difficult', 'error', 'failed',
            'hard', 'impossible', 'mistake', 'negative', 'never', 'problem', 'stop',
            'terrible', 'warning', 'worst', 'wrong',
            'scandal', 'shocking', 'tragic', 'controversial', 'banned', 'forbidden',
            'warning', 'toxic', 'risk', 'dangerous', 'chronic', 'hidden', 'avoid',
            'mistakes', 'worst', 'errors', 'costly', 'stop', 'never', 'ruin', 'failing'
        ];
        
        foreach ($positive_words as $word) {
            if (preg_match('/\b' . preg_quote($word, '/') . '\b/', $text_lower)) {
                $positive_found[] = $word;
            }
        }
        
        foreach ($negative_words as $word) {
            if (preg_match('/\b' . preg_quote($word, '/') . '\b/', $text_lower)) {
                $negative_found[] = $word;
            }
        }
        
        $has_sentiment = !empty($positive_found) || !empty($negative_found);
        
        if (!empty($positive_found)) {
            $description = __('✓ Contains positive sentiment', 'rankwell-seo-checklist');
        } elseif (!empty($negative_found)) {
            $description = __('⚠️ Contains negative sentiment', 'rankwell-seo-checklist');
        } else {
            $description = __('✗ No strong sentiment words', 'rankwell-seo-checklist');
        }
        
        return [
            'has_sentiment' => $has_sentiment,
            'positive_words' => $positive_found,
            'negative_words' => $negative_found,
            'description' => $description
        ];
    }
    
    /**
     * Helper: Detect quick answer format
     *
     * @param string $content Content to analyze
     * @return array Quick answer detection results
     */
    protected static function detect_quick_answer_format($content)
    {
        $checks = [
            'has_format' => false,
            'position_score' => 0,
            'format_type' => '',
            'found_at' => 'not_found',
            'details' => []
        ];
        
        $clean_content = wp_strip_all_tags($content);
        
        // Check for lists (bulleted or numbered)
        if (preg_match_all('/(<ul>|<ol>|<li>)/i', $content, $list_matches)) {
            $list_count = count($list_matches[0]);
            if ($list_count >= 3) {
                $checks['has_format'] = true;
                $checks['format_type'] = ($list_matches[1][0] == 'ol') ? 'numbered_list' : 'bulleted_list';
                $checks['found_at'] = 'anywhere';
                $checks['position_score'] = 60;
                $checks['details']['list_count'] = $list_count;
                
                // Check position
                $first_500 = substr($content, 0, 500);
                if (preg_match('/(<ul>|<ol>|<li>)/i', $first_500)) {
                    $checks['position_score'] = 80;
                    $checks['found_at'] = 'beginning';
                }
            }
            return $checks;
        }
        
        // Check for FAQ patterns
        $faq_patterns = [
            'question' => '/(?:q:|question:|faq|questions? to ask)/i',
            'answer' => '/(?:a:|answer:|answers?)/i'
        ];
        
        $faq_question_count = preg_match_all($faq_patterns['question'], $content, $q_matches);
        $faq_answer_count = preg_match_all($faq_patterns['answer'], $content, $a_matches);
        
        if ($faq_question_count >= 2 && $faq_answer_count >= 2) {
            $checks['has_format'] = true;
            $checks['format_type'] = 'faq';
            $checks['found_at'] = 'anywhere';
            $checks['position_score'] = 70;
            $checks['details']['question_count'] = $faq_question_count;
            $checks['details']['answer_count'] = $faq_answer_count;
            return $checks;
        }
        
        // Check for tables
        if (preg_match_all('/<table.*?>.*?<\/table>/is', $content, $table_matches)) {
            foreach ($table_matches[0] as $table) {
                $row_count = preg_match_all('/<tr>/i', $table);
                if ($row_count >= 3) {
                    $checks['has_format'] = true;
                    $checks['format_type'] = 'table';
                    $checks['found_at'] = 'anywhere';
                    $checks['position_score'] = 65;
                    $checks['details']['row_count'] = $row_count;
                    return $checks;
                }
            }
        }
        
        // Check for definition lists
        if (preg_match_all('/<dl>.*?<\/dl>/is', $content, $dl_matches)) {
            $dl_count = count($dl_matches[0]);
            if ($dl_count >= 1) {
                $checks['has_format'] = true;
                $checks['format_type'] = 'definition_list';
                $checks['found_at'] = 'anywhere';
                $checks['position_score'] = 60;
                $checks['details']['dl_count'] = $dl_count;
                return $checks;
            }
        }
        
        // Check for numbered steps
        $numbered_steps = preg_match_all('/\b\d+\.\s+[A-Z][^.!?]*[.!?]/i', $clean_content, $step_matches);
        if ($numbered_steps >= 3) {
            $checks['has_format'] = true;
            $checks['format_type'] = 'numbered_steps';
            $checks['found_at'] = 'anywhere';
            $checks['position_score'] = 75;
            $checks['details']['step_count'] = $numbered_steps;
            return $checks;
        }
        
        // Check for bullet points
        $bullet_points = preg_match_all('/^(?:\*|\-|\+)\s+.+/im', $clean_content, $bullet_matches);
        if ($bullet_points >= 3) {
            $checks['has_format'] = true;
            $checks['format_type'] = 'bullet_points';
            $checks['found_at'] = 'anywhere';
            $checks['position_score'] = 70;
            $checks['details']['bullet_count'] = $bullet_points;
            return $checks;
        }
        
        return $checks;
    }
    
    /**
     * Helper: Check if keyword is used as anchor text
     *
     * @param string $content Content to check
     * @param string $keyword Keyword to check
     * @return bool Whether keyword is used as anchor text
     */
    protected static function check_keyword_in_anchor($content, $keyword)
    {
        preg_match_all('/<a[^>]+>(.*?)<\/a>/i', $content, $matches);
        
        if (empty($matches[1])) {
            return false;
        }
        
        foreach ($matches[1] as $anchor_text) {
            $clean_anchor = wp_strip_all_tags($anchor_text);
            if (stripos($clean_anchor, $keyword) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Get suggestions based on failed checks
     *
     * @param array  $checks Array of checks
     * @param string $content Post content
     * @param string $keyword Focus keyword
     * @return array Suggestions for improvement
     */
    protected static function get_suggestions($checks, $content, $keyword)
    {
        $suggestions = [];
        $clean_content = wp_strip_all_tags($content);
        $word_count = str_word_count($clean_content);
        
        // Group checks by category for better suggestions
        $failed_checks = array_filter($checks, function($check) {
            return in_array($check['status'], ['fail', 'warning']);
        });
        
        foreach ($failed_checks as $check) {
            switch ($check['id']) {
                case 'content_length':
                    if ($word_count < 300) {
                        $suggestions[] = [
                            'priority' => 'high',
                            'title' => __('Increase Content Length', 'rankwell-seo-checklist'),
                            'message' => sprintf(__('Add %d+ more words (currently %d).', 'rankwell-seo-checklist'), 
                                500 - $word_count, 
                                $word_count),
                            'action' => __('Expand sections, add examples, or include more details.', 'rankwell-seo-checklist')
                        ];
                    }
                    break;
                    
                case 'title_keyword':
                    $suggestions[] = [
                        'priority' => 'high',
                        'title' => __('Add Keyword to Title', 'rankwell-seo-checklist'),
                        'message' => __('Title should include primary keyword for better rankings.', 'rankwell-seo-checklist'),
                        'action' => __('Place keyword near the beginning of the title.', 'rankwell-seo-checklist')
                    ];
                    break;
                    
                case 'title_word_count':
                    $suggestions[] = [
                        'priority' => 'medium',
                        'title' => __('Optimize Title Word Count', 'rankwell-seo-checklist'),
                        'message' => __('Titles with 5-9 words tend to perform best in search results.', 'rankwell-seo-checklist'),
                        'action' => __('Adjust your title to be between 5-9 words for optimal CTR.', 'rankwell-seo-checklist')
                    ];
                    break;
                    
                case 'url_slug':
                    $suggestions[] = [
                        'priority' => 'high',
                        'title' => __('Shorten URL Slug', 'rankwell-seo-checklist'),
                        'message' => __('URL slugs should be 65 characters or less for better usability.', 'rankwell-seo-checklist'),
                        'action' => __('Shorten the slug and consider adding the keyword.', 'rankwell-seo-checklist')
                    ];
                    break;
                    
                case 'headings':
                    $suggestions[] = [
                        'priority' => 'medium',
                        'title' => __('Improve Heading Structure', 'rankwell-seo-checklist'),
                        'message' => __('Use H2 headings to organize content and include keywords.', 'rankwell-seo-checklist'),
                        'action' => __('Add at least one H2 heading and 1-2 H3 headings with variations of your keyword.', 'rankwell-seo-checklist')
                    ];
                    break;
                    
                case 'title_number':
                    $suggestions[] = [
                        'priority' => 'medium',
                        'title' => __('Add Number to Title', 'rankwell-seo-checklist'),
                        'message' => __('Titles with numbers get 12-15% higher click-through rates.', 'rankwell-seo-checklist'),
                        'action' => __('Add a number (like "5 Ways" or "10 Tips") to your title.', 'rankwell-seo-checklist')
                    ];
                    break;
                    
                case 'title_power_words':
                    $suggestions[] = [
                        'priority' => 'medium',
                        'title' => __('Add Power Words to Title', 'rankwell-seo-checklist'),
                        'message' => __('Power words create emotional impact and improve CTR by 12-15%.', 'rankwell-seo-checklist'),
                        'action' => __('Try: "Ultimate Guide", "Proven Methods", "Secret Strategy", or "Essential Tips".', 'rankwell-seo-checklist'),
                        'examples' => [
                            'Instead of: "How to Lose Weight"',
                            'Try: "The Ultimate Guide to Effortless Weight Loss"',
                            'Or: "7 Proven Strategies for Rapid Weight Loss"'
                        ]
                    ];
                    break;
                    
                case 'title_uncommon_words':
                    $suggestions[] = [
                        'priority' => 'low',
                        'title' => __('Add Uncommon Words to Title', 'rankwell-seo-checklist'),
                        'message' => __('Uncommon words can improve click-through rates by making titles more unique.', 'rankwell-seo-checklist'),
                        'action' => __('Add words like "heart", "actually", "found", or "ways" to stand out.', 'rankwell-seo-checklist'),
                        'examples' => [
                            'Instead of: "Best Cooking Tips"',
                            'Try: "21 Ways Your Heart Actually Loves Cooking"',
                            'Or: "What We Found About Life-Changing Cooking"'
                        ]
                    ];
                    break;
                    
                case 'keyword_anchor':
                    $suggestions[] = [
                        'priority' => 'medium',
                        'title' => __('Avoid Keyword as Anchor Text', 'rankwell-seo-checklist'),
                        'message' => __('Using exact keywords as anchor text looks unnatural to search engines.', 'rankwell-seo-checklist'),
                        'action' => __('Use descriptive anchor text instead of exact keywords.', 'rankwell-seo-checklist'),
                        'examples' => [
                            'Instead of: "Learn about <a href="#">keyword</a>"',
                            'Try: "Learn about <a href="#">this important strategy</a>"'
                        ]
                    ];
                    break;
                    
                case 'quick_answer':
                    $has_quick_answer = isset($check['extra_data']['has_format']) ? $check['extra_data']['has_format'] : false;
                    
                    if (!$has_quick_answer) {
                        $suggestions[] = [
                            'priority' => 'medium',
                            'title' => __('Add Quick Answer Format', 'rankwell-seo-checklist'),
                            'message' => __('Quick answer formats increase chances of featured snippets by 35%.', 'rankwell-seo-checklist'),
                            'action' => __('Add bullet points, numbered lists, or a FAQ section anywhere in the content.', 'rankwell-seo-checklist'),
                            'examples' => [
                                '• Bullet points with key takeaways',
                                '1. Numbered steps for how-to content',
                                'Q: Common question? A: Clear answer'
                            ]
                        ];
                    }
                    break;
                    
                case 'keyword_bolded':
                    $suggestions[] = [
                        'priority' => 'low',
                        'title' => __('Bold Your Keyword', 'rankwell-seo-checklist'),
                        'message' => __('Bolding keywords helps emphasize important terms for readers and search engines.', 'rankwell-seo-checklist'),
                        'action' => __('Wrap your primary keyword in <strong> tags at least once.', 'rankwell-seo-checklist'),
                        'examples' => [
                            'This is why <strong>keyword</strong> is so important...',
                            'The main <strong>keyword</strong> should be emphasized...'
                        ]
                    ];
                    break;
                    
                case 'transition_words':
                    $suggestions[] = [
                        'priority' => 'low',
                        'title' => __('Add Transition Words', 'rankwell-seo-checklist'),
                        'message' => __('Transition words improve content flow and readability.', 'rankwell-seo-checklist'),
                        'action' => __('Add words like "however", "therefore", "for example", or "in conclusion".', 'rankwell-seo-checklist')
                    ];
                    break;
                    
                case 'content_conclusion':
                    $suggestions[] = [
                        'priority' => 'low',
                        'title' => __('Add a Conclusion', 'rankwell-seo-checklist'),
                        'message' => __('Conclusions help summarize key points and improve content completeness.', 'rankwell-seo-checklist'),
                        'action' => __('Add a final paragraph starting with "In conclusion" or "To summarize".', 'rankwell-seo-checklist')
                    ];
                    break;
                    
                case 'paragraph_structure':
                    // Extract paragraph count from description
                    if (preg_match('/(\d+)\s+paragraphs/', $check['description'], $matches)) {
                        $para_count = intval($matches[1]);
                        if ($para_count < 3) {
                            $suggestions[] = [
                                'priority' => 'medium',
                                'title' => __('Add More Paragraphs', 'rankwell-seo-checklist'),
                                'message' => __('Content should have at least 3-5 paragraphs for better readability.', 'rankwell-seo-checklist'),
                                'action' => __('Break long content into smaller paragraphs of 50-200 words each.', 'rankwell-seo-checklist')
                            ];
                        }
                    }
                    break;
            }
        }
        
        // Sort by priority
        usort($suggestions, function($a, $b) {
            $priority_order = ['high' => 3, 'medium' => 2, 'low' => 1];
            return ($priority_order[$b['priority']] ?? 0) <=> ($priority_order[$a['priority']] ?? 0);
        });
        
        return $suggestions;
    }
}