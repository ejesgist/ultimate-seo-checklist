<?php
/**
 * Rankwell SEO Checklist Engine - Core Checks
 * 
 * @package Rankwell\SEO_Checklist\Engine
 * @since 1.3.0
 */

namespace Rankwell\SEO_Checklist\Engine;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Core_Checks extends Base
{
    /**
     * Run core SEO checks
     *
     * @param WP_Post $post Post object
     * @param string  $keyword Focus keyword
     * @param string  $content Post content
     * @param array   $seo_data SEO plugin data
     * @param array   $enabled_checks Enabled checks
     * @return array Core SEO checks
     */
    public static function run_checks($post, $keyword, $content, $seo_data, $enabled_checks)
    {
        $checks = [];
        $clean_content = wp_strip_all_tags($content);
        $word_count = str_word_count($clean_content);
        $keyword_lower = strtolower($keyword);
        
        // 1. Keyword in Title
        if (self::is_check_enabled('title_keyword', $enabled_checks)) {
            $title = $seo_data['title'] ?: $post->post_title;
            $has_title_keyword = stripos($title, $keyword) !== false;
            $checks[] = [
                'id' => 'title_keyword',
                'label' => __('Keyword in Title', 'rankwell-seo-checklist'),
                'status' => $has_title_keyword ? 'pass' : 'fail',
                'description' => $has_title_keyword ? 
                    __('✓ Found in title', 'rankwell-seo-checklist') : 
                    __('✗ Add keyword to title', 'rankwell-seo-checklist'),
                'weight' => 15
            ];
        }
        
        // 2. Title Word Count (5-9 words recommended)
        if (self::is_check_enabled('title_word_count', $enabled_checks)) {
            $title = $seo_data['title'] ?: $post->post_title;
            $title_words = str_word_count($title);
            $title_word_count_status = ($title_words >= 5 && $title_words <= 9) ? 'pass' : 
                                      (($title_words >= 4 && $title_words <= 12) ? 'warning' : 'fail');
            $checks[] = [
                'id' => 'title_word_count',
                'label' => __('Title Word Count (5-9 words)', 'rankwell-seo-checklist'),
                'status' => $title_word_count_status,
                'description' => sprintf(__('%d words', 'rankwell-seo-checklist'), $title_words),
                'weight' => 8
            ];
        }
        
        // 3. Title Length (50-60 characters optimal)
        if (self::is_check_enabled('title_length', $enabled_checks)) {
            $title = $seo_data['title'] ?: $post->post_title;
            $title_length = strlen(html_entity_decode($title, ENT_QUOTES, 'UTF-8'));
            $title_status = ($title_length >= 50 && $title_length <= 60) ? 'pass' : 
                           (($title_length >= 30 && $title_length <= 70) ? 'warning' : 'fail');
            $checks[] = [
                'id' => 'title_length',
                'label' => __('Title Length (50-60 chars)', 'rankwell-seo-checklist'),
                'status' => $title_status,
                'description' => sprintf(__('%d characters', 'rankwell-seo-checklist'), $title_length),
                'weight' => 8
            ];
        }
        
        // 4. Title Contains Number
        if (self::is_check_enabled('title_number', $enabled_checks)) {
            $title = $seo_data['title'] ?: $post->post_title;
            $has_number = preg_match('/\d+/', $title);
            $checks[] = [
                'id' => 'title_number',
                'label' => __('Title Contains Number', 'rankwell-seo-checklist'),
                'status' => $has_number ? 'pass' : 'warning',
                'description' => $has_number ? 
                    __('✓ Contains number', 'rankwell-seo-checklist') : 
                    __('✗ Add a number for better CTR', 'rankwell-seo-checklist'),
                'weight' => 5
            ];
        }
        
        // 5. Title Power Words
        if (self::is_check_enabled('title_power_words', $enabled_checks)) {
            $title = $seo_data['title'] ?: $post->post_title;
            $power_words_data = self::find_power_words($title);
            $power_word_count = $power_words_data['count'];
            $power_word_status = ($power_word_count >= 1) ? 'pass' : 'warning';
            
            $description = $power_word_count > 0 ? 
                sprintf(__('✓ Contains %d power word(s)', 'rankwell-seo-checklist'), $power_word_count) : 
                __('✗ Add power words for impact', 'rankwell-seo-checklist');
            
            // Add category info if available
            if (!empty($power_words_data['categories'])) {
                $top_category = array_key_first($power_words_data['categories']);
                $description .= sprintf(__(' (%s)', 'rankwell-seo-checklist'), $top_category);
            }
            
            $checks[] = [
                'id' => 'title_power_words',
                'label' => __('Title Power Words', 'rankwell-seo-checklist'),
                'status' => $power_word_status,
                'description' => $description,
                'weight' => 6
            ];
        }
        
        // 6. Title Uncommon Words
        if (self::is_check_enabled('title_uncommon_words', $enabled_checks)) {
            $title = $seo_data['title'] ?: $post->post_title;
            $uncommon_words_found = self::find_uncommon_words($title);
            $uncommon_word_count = count($uncommon_words_found);
            $uncommon_word_status = ($uncommon_word_count >= 1) ? 'pass' : 'info';
            $checks[] = [
                'id' => 'title_uncommon_words',
                'label' => __('Title Uncommon Words', 'rankwell-seo-checklist'),
                'status' => $uncommon_word_status,
                'description' => $uncommon_word_count > 0 ? 
                    sprintf(__('✓ Contains %d uncommon word(s)', 'rankwell-seo-checklist'), $uncommon_word_count) : 
                    __('Consider adding uncommon words', 'rankwell-seo-checklist'),
                'weight' => 4
            ];
        }
        
        // 7. Title Sentiment
        if (self::is_check_enabled('title_sentiment', $enabled_checks)) {
            $title = $seo_data['title'] ?: $post->post_title;
            $sentiment = self::analyze_sentiment($title);
            $sentiment_status = ($sentiment['has_sentiment']) ? 'pass' : 'warning';
            $checks[] = [
                'id' => 'title_sentiment',
                'label' => __('Title Sentiment', 'rankwell-seo-checklist'),
                'status' => $sentiment_status,
                'description' => $sentiment['description'],
                'weight' => 4
            ];
        }
        
        // 8. Meta Description
        if (self::is_check_enabled('meta_description', $enabled_checks)) {
            $meta_desc = $seo_data['description'] ?: wp_trim_words($clean_content, 25);
            $has_meta_keyword = stripos($meta_desc, $keyword) !== false;
            $meta_length = strlen($meta_desc);
            $meta_status = ($meta_length >= 120 && $meta_length <= 160) ? 'pass' : 'warning';
            
            $checks[] = [
                'id' => 'meta_description',
                'label' => __('Meta Description (120-160 chars)', 'rankwell-seo-checklist'),
                'status' => $meta_status,
                'description' => sprintf(__('%d chars%s', 'rankwell-seo-checklist'), 
                    $meta_length, 
                    $has_meta_keyword ? ', ✓ has keyword' : ', ✗ add keyword'),
                'weight' => 10
            ];
        }
        
        // 9. URL Slug Length (≤65 characters)
        if (self::is_check_enabled('url_slug', $enabled_checks)) {
            $slug = basename(get_permalink($post->ID));
            $slug_length = strlen($slug);
            $slug_status = ($slug_length <= 65) ? 'pass' : 'fail';
            $has_slug_keyword = stripos($slug, sanitize_title($keyword)) !== false;
            
            $slug_description = sprintf(__('%d chars', 'rankwell-seo-checklist'), $slug_length);
            if ($has_slug_keyword) {
                $slug_description .= ', ✓ has keyword';
            }
            
            $checks[] = [
                'id' => 'url_slug',
                'label' => __('URL Slug (≤65 chars)', 'rankwell-seo-checklist'),
                'status' => $slug_status,
                'description' => $slug_description,
                'weight' => 8
            ];
        }
        
        // 10. Content Length
        if (self::is_check_enabled('content_length', $enabled_checks)) {
            $content_status = ($word_count >= 500) ? 'pass' : 
                             (($word_count >= 300) ? 'warning' : 'fail');
            $checks[] = [
                'id' => 'content_length',
                'label' => __('Content Length (500+ words)', 'rankwell-seo-checklist'),
                'status' => $content_status,
                'description' => sprintf(__('%d words', 'rankwell-seo-checklist'), $word_count),
                'weight' => 15
            ];
        }
        
        // 11. Keyword Density
        if (self::is_check_enabled('keyword_density', $enabled_checks) && $word_count > 0) {
            $clean_content_lower = strtolower($clean_content);
            $keyword_count = substr_count($clean_content_lower, $keyword_lower);
            $density = ($keyword_count / $word_count) * 100;
            $density_status = ($density >= 0.5 && $density <= 3.0) ? 'pass' : 'warning';
            $checks[] = [
                'id' => 'keyword_density',
                'label' => __('Keyword Density (0.5-3.0%)', 'rankwell-seo-checklist'),
                'status' => $density_status,
                'description' => sprintf(__('%.2f%%', 'rankwell-seo-checklist'), $density),
                'weight' => 8
            ];
        }
        
        return $checks;
    }
}