<?php
/**
 * Rankwell SEO Checklist Engine - Advanced Checks
 * 
 * @package Rankwell\SEO_Checklist\Engine
 * @since 1.3.0
 */

namespace Rankwell\SEO_Checklist\Engine;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Advanced_Checks extends Base
{
    /**
     * Run advanced checks
     *
     * @param WP_Post $post Post object
     * @param string  $keyword Focus keyword
     * @param string  $content Post content
     * @param array   $enabled_checks Enabled checks
     * @return array Advanced checks
     */
    public static function run_checks($post, $keyword, $content, $enabled_checks)
    {
        $checks = [];
        $clean_content = wp_strip_all_tags($content);
        $keyword_lower = strtolower($keyword);
        
        // 1. Quick Answer Format
        if (self::is_check_enabled('quick_answer', $enabled_checks)) {
            $quick_answer_data = self::detect_quick_answer_format($content);
            $has_quick_answer = $quick_answer_data['has_format'];
            
            $quick_answer_status = 'warning';
            $quick_answer_description = __('✗ No quick answer format found', 'rankwell-seo-checklist');
            
            if ($has_quick_answer) {
                $quick_answer_status = 'pass';
                $quick_answer_description = __('✓ Quick answer format found', 'rankwell-seo-checklist');
                if (isset($quick_answer_data['format_type'])) {
                    $quick_answer_description .= ' (' . $quick_answer_data['format_type'] . ')';
                }
            }
            
            $checks[] = [
                'id' => 'quick_answer',
                'label' => __('Quick Answer Format', 'rankwell-seo-checklist'),
                'status' => $quick_answer_status,
                'description' => $quick_answer_description,
                'weight' => 6
            ];
        }
        
        // 2. Keyword as Anchor Text (Warning if used)
        if (self::is_check_enabled('keyword_anchor', $enabled_checks)) {
            $keyword_in_anchor = self::check_keyword_in_anchor($content, $keyword);
            $checks[] = [
                'id' => 'keyword_anchor',
                'label' => __('Keyword as Anchor Text', 'rankwell-seo-checklist'),
                'status' => $keyword_in_anchor ? 'warning' : 'pass',
                'description' => $keyword_in_anchor ? 
                    __('⚠️ Avoid using exact keyword as anchor text', 'rankwell-seo-checklist') : 
                    __('✓ Using natural anchor text', 'rankwell-seo-checklist'),
                'weight' => 4
            ];
        }
        
        // 3. Outbound/Authority Links
        if (self::is_check_enabled('authority_links', $enabled_checks)) {
            $home_url = home_url();
            $external_links = preg_match_all(
                '/<a[^>]+href=["\'](https?:\/\/[^"\']+)["\'][^>]*>/i',
                $content,
                $link_matches
            );
            
            $authority_sites = ['wikipedia.org', 'nytimes.com', 'bbc.com', 'forbes.com', 'gov.', 'edu', '.org'];
            $has_authority_link = false;
            
            if ($external_links > 0 && !empty($link_matches[1])) {
                foreach ($link_matches[1] as $url) {
                    if (strpos($url, $home_url) === false) {
                        foreach ($authority_sites as $authority) {
                            if (stripos($url, $authority) !== false) {
                                $has_authority_link = true;
                                break 2;
                            }
                        }
                    }
                }
            }
            
            $checks[] = [
                'id' => 'authority_links',
                'label' => __('Authority Links', 'rankwell-seo-checklist'),
                'status' => $has_authority_link ? 'pass' : 'warning',
                'description' => $has_authority_link ? 
                    __('✓ Links to authority sites', 'rankwell-seo-checklist') : 
                    __('✗ Add authoritative sources', 'rankwell-seo-checklist'),
                'weight' => 4
            ];
        }
        
        // 4. Content Freshness
        if (self::is_check_enabled('content_freshness', $enabled_checks)) {
            $post_age = time() - strtotime($post->post_date);
            $is_fresh = ($post_age < (30 * DAY_IN_SECONDS));
            $checks[] = [
                'id' => 'content_freshness',
                'label' => __('Content Freshness', 'rankwell-seo-checklist'),
                'status' => $is_fresh ? 'pass' : 'warning',
                'description' => $is_fresh ? 
                    __('✓ Recently published/updated', 'rankwell-seo-checklist') : 
                    __('✗ Consider updating content', 'rankwell-seo-checklist'),
                'weight' => 4
            ];
        }
        
        // 5. Featured Image
        if (self::is_check_enabled('featured_image', $enabled_checks)) {
            $has_featured_image = has_post_thumbnail($post->ID);
            $checks[] = [
                'id' => 'featured_image',
                'label' => __('Featured Image', 'rankwell-seo-checklist'),
                'status' => $has_featured_image ? 'pass' : 'warning',
                'description' => $has_featured_image ? 
                    __('✓ Set and optimized', 'rankwell-seo-checklist') : 
                    __('✗ Add featured image', 'rankwell-seo-checklist'),
                'weight' => 6
            ];
        }
        
        // 6. Image Dimensions (CLS prevention)
        if (self::is_check_enabled('image_dimensions', $enabled_checks)) {
            preg_match_all('/<img[^>]+>/i', $content, $img_matches);
            $images_without_dimensions = 0;
            
            foreach ($img_matches[0] as $img_tag) {
                if (!preg_match('/(width|height)=["\']/i', $img_tag)) {
                    $images_without_dimensions++;
                }
            }
            
            $total_images = count($img_matches[0]);
            $image_dim_status = ($images_without_dimensions === 0 && $total_images > 0) ? 'pass' : 
                               ($total_images === 0 ? 'info' : 'warning');
            
            $checks[] = [
                'id' => 'image_dimensions',
                'label' => __('Image Dimensions', 'rankwell-seo-checklist'),
                'status' => $image_dim_status,
                'description' => sprintf(__('%d/%d images have dimensions', 'rankwell-seo-checklist'), 
                    ($total_images - $images_without_dimensions), 
                    $total_images),
                'weight' => 4
            ];
        }
        
        // 7. Image File Size Warning
        if (self::is_check_enabled('image_file_size', $enabled_checks)) {
            preg_match_all('/<img[^>]+src=["\']([^"\']+)["\']/i', $content, $img_src_matches);
            $total_images = count($img_src_matches[1]);
            
            if ($total_images > 0) {
                $checks[] = [
                    'id' => 'image_file_size',
                    'label' => __('Image File Size', 'rankwell-seo-checklist'),
                    'status' => 'info',
                    'description' => sprintf(__('%d images found', 'rankwell-seo-checklist'), $total_images),
                    'weight' => 3
                ];
            }
        }
        
        return $checks;
    }
}