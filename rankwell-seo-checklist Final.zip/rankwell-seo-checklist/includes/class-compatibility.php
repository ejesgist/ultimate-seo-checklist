<?php
/**
 * Rankwell SEO Checklist - Compatibility Layer
 * 
 * @package Rankwell\SEO_Checklist
 * @since 1.0.0
 */

namespace Rankwell\SEO_Checklist;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Compatibility
{
    /**
     * Detect active SEO plugins
     *
     * @return array Active SEO plugins
     */
    public static function detect_seo_plugins()
    {
        $active_plugins = [];
        
        // Check for Yoast SEO
        if (defined('WPSEO_VERSION')) {
            $active_plugins['yoast'] = 'Yoast SEO ' . WPSEO_VERSION;
        }
        
        // Check for Rank Math
        if (defined('RANK_MATH_VERSION')) {
            $active_plugins['rankmath'] = 'Rank Math ' . RANK_MATH_VERSION;
        }
        
        // Check for All In One SEO
        if (defined('AIOSEO_VERSION')) {
            $active_plugins['aioseo'] = 'All In One SEO ' . AIOSEO_VERSION;
        }
        
        // Check for SEOPress
        if (defined('SEOPRESS_VERSION')) {
            $active_plugins['seopress'] = 'SEOPress ' . SEOPRESS_VERSION;
        }
        
        // Check for The SEO Framework
        if (defined('THE_SEO_FRAMEWORK_VERSION')) {
            $active_plugins['the_seo_framework'] = 'The SEO Framework ' . THE_SEO_FRAMEWORK_VERSION;
        }
        
        return $active_plugins;
    }
    
    /**
     * Get SEO data from all detected plugins
     *
     * @param int $post_id Post ID
     * @return array All SEO data
     */
    public static function get_all_seo_data($post_id)
    {
        $data = [
            'titles' => [],
            'descriptions' => [],
            'keywords' => [],
            'canonicals' => [],
            'robots' => []
        ];
        
        $plugins = self::detect_seo_plugins();
        
        foreach ($plugins as $plugin_key => $plugin_name) {
            $plugin_data = self::get_plugin_data($plugin_key, $post_id);
            
            if (!empty($plugin_data['title'])) {
                $data['titles'][$plugin_key] = $plugin_data['title'];
            }
            
            if (!empty($plugin_data['description'])) {
                $data['descriptions'][$plugin_key] = $plugin_data['description'];
            }
            
            if (!empty($plugin_data['keyword'])) {
                $data['keywords'][$plugin_key] = $plugin_data['keyword'];
            }
            
            if (!empty($plugin_data['canonical'])) {
                $data['canonicals'][$plugin_key] = $plugin_data['canonical'];
            }
            
            if (!empty($plugin_data['robots'])) {
                $data['robots'][$plugin_key] = $plugin_data['robots'];
            }
        }
        
        return $data;
    }
    
    /**
     * Get data from specific plugin
     *
     * @param string $plugin Plugin key
     * @param int    $post_id Post ID
     * @return array Plugin data
     */
    private static function get_plugin_data($plugin, $post_id)
    {
        $data = [
            'title' => '',
            'description' => '',
            'keyword' => '',
            'canonical' => '',
            'robots' => ''
        ];
        
        $meta_keys = Engine\Engine::SEO_PLUGINS[$plugin] ?? [];
        
        if (empty($meta_keys)) {
            return $data;
        }
        
        foreach ($meta_keys as $key => $meta_key) {
            if (isset($data[$key])) {
                $value = get_post_meta($post_id, $meta_key, true);
                if (!empty($value)) {
                    $data[$key] = $value;
                }
            }
        }
        
        return $data;
    }
    
    /**
     * Check for conflicts between plugins
     *
     * @param int $post_id Post ID
     * @return array Conflict messages
     */
    public static function check_conflicts($post_id)
    {
        $seo_data = self::get_all_seo_data($post_id);
        $conflicts = [];
        
        // Check for multiple titles
        if (count($seo_data['titles']) > 1) {
            $conflicts[] = __('Multiple SEO plugins setting titles', 'rankwell-seo-checklist');
        }
        
        // Check for multiple descriptions
        if (count($seo_data['descriptions']) > 1) {
            $conflicts[] = __('Multiple SEO plugins setting descriptions', 'rankwell-seo-checklist');
        }
        
        // Check for multiple canonicals
        if (count($seo_data['canonicals']) > 1) {
            $canonicals = array_unique(array_values($seo_data['canonicals']));
            if (count($canonicals) > 1) {
                $conflicts[] = __('Conflicting canonical URLs', 'rankwell-seo-checklist');
            }
        }
        
        return $conflicts;
    }
    
    /**
     * Get recommended primary plugin based on detection
     *
     * @return string|null Recommended plugin key
     */
    public static function get_recommended_plugin()
    {
        $plugins = self::detect_seo_plugins();
        
        // Return the first detected plugin
        return !empty($plugins) ? array_key_first($plugins) : null;
    }
    
    /**
     * Add compatibility notice to admin
     *
     * @return void
     */
    public static function admin_notice()
    {
        $active_plugins = self::detect_seo_plugins();
        
        if (count($active_plugins) > 1) {
            $plugin_names = implode(', ', array_values($active_plugins));
            ?>
            <div class="notice notice-warning">
                <p>
                    <?php printf(
                        __('Rankwell SEO Checklist detected multiple SEO plugins: %s. This may cause conflicts.', 'rankwell-seo-checklist'),
                        $plugin_names
                    ); ?>
                </p>
            </div>
            <?php
        }
    }
}