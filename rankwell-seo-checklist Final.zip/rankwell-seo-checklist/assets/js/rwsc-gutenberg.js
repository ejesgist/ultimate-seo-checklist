/**
 * Rankwell SEO Checklist - Gutenberg Integration
 */

(function() {
    const { registerPlugin } = wp.plugins;
    const { PluginDocumentSettingPanel } = wp.editPost;
    const { TextControl, Button, Spinner, Notice, PanelRow } = wp.components;
    const { useState, useEffect } = wp.element;
    const { dispatch, select } = wp.data;
    const { __ } = wp.i18n;

    const RankwellSEOPanel = () => {
        const [keyword, setKeyword] = useState('');
        const [loading, setLoading] = useState(false);
        const [results, setResults] = useState(null);
        const [score, setScore] = useState(null);
        const [checks, setChecks] = useState([]);
        const [suggestions, setSuggestions] = useState([]);
        const [error, setError] = useState(null);

        // Get post ID
        const postId = select('core/editor').getCurrentPostId();
        
        // Load saved keyword
        useEffect(() => {
            if (postId && window.rwscConfig) {
                // Get saved keyword from post meta
                const savedKeyword = select('core/editor').getEditedPostAttribute('meta')?._rwsc_focus_keyword;
                if (savedKeyword) {
                    setKeyword(savedKeyword);
                }
            }
        }, [postId]);

        // Auto-check on keyword change
        useEffect(() => {
            const autoCheck = window.rwscConfig?.autoCheck;
            if (autoCheck && keyword && keyword.length >= 2) {
                const timer = setTimeout(() => {
                    runChecklist();
                }, 2000);
                return () => clearTimeout(timer);
            }
        }, [keyword]);

        const saveKeyword = async () => {
            if (!postId) return;
            
            try {
                const response = await fetch(window.rwscConfig.ajaxUrl, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: new URLSearchParams({
                        action: 'rwsc_save_keyword',
                        post_id: postId,
                        keyword: keyword,
                        nonce: window.rwscConfig.nonce
                    })
                });
                
                const data = await response.json();
                if (data.success) {
                    // Update post meta
                    dispatch('core/editor').editPost({
                        meta: { _rwsc_focus_keyword: keyword }
                    });
                }
            } catch (err) {
                console.error('Error saving keyword:', err);
            }
        };

        const runChecklist = async () => {
            if (loading) return;
            
            if (!keyword || keyword.length < 2) {
                setError(__('Please enter a focus keyword', 'rankwell-seo-checklist'));
                return;
            }
            
            // Get content from editor
            const content = select('core/editor').getEditedPostContent();
            if (!content) {
                setError(__('No content to analyze', 'rankwell-seo-checklist'));
                return;
            }
            
            setLoading(true);
            setError(null);
            
            try {
                const response = await fetch(window.rwscConfig.ajaxUrl, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: new URLSearchParams({
                        action: 'rwsc_run_preflight',
                        post_id: postId,
                        keyword: keyword,
                        content: content,
                        nonce: window.rwscConfig.nonce
                    })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    setResults(data.data);
                    setScore(data.data.score);
                    setChecks(data.data.checks || []);
                    setSuggestions(data.data.suggestions || []);
                    
                    // Save keyword if not saved
                    if (keyword !== select('core/editor').getEditedPostAttribute('meta')?._rwsc_focus_keyword) {
                        saveKeyword();
                    }
                } else {
                    setError(data.data?.message || __('Error running checklist', 'rankwell-seo-checklist'));
                }
            } catch (err) {
                setError(__('Error connecting to server', 'rankwell-seo-checklist'));
                console.error('Error:', err);
            } finally {
                setLoading(false);
            }
        };

        const getStatusColor = (status) => {
            switch(status) {
                case 'pass': return '#00a32a';
                case 'warning': return '#dba617';
                case 'fail': return '#d63638';
                default: return '#646970';
            }
        };

        const getPriorityLabel = (priority) => {
            switch(priority) {
                case 'high': return __('High', 'rankwell-seo-checklist');
                case 'medium': return __('Medium', 'rankwell-seo-checklist');
                case 'low': return __('Low', 'rankwell-seo-checklist');
                default: return priority;
            }
        };

        return (
            <PluginDocumentSettingPanel
                name="rankwell-seo-checklist"
                title={__('SEO Checklist', 'rankwell-seo-checklist')}
                className="rwsc-gutenberg-panel"
            >
                <div className="rwsc-gutenberg-container">
                    <div className="rwsc-keyword-field">
                        <TextControl
                            label={__('Focus Keyword:', 'rankwell-seo-checklist')}
                            value={keyword}
                            onChange={(value) => setKeyword(value)}
                            placeholder={__('Enter primary keyword', 'rankwell-seo-checklist')}
                            onBlur={saveKeyword}
                        />
                    </div>
                    
                    <div className="rwsc-actions">
                        <Button
                            isPrimary
                            onClick={runChecklist}
                            disabled={loading}
                        >
                            {loading ? __('Analyzing...', 'rankwell-seo-checklist') : __('Run Checklist', 'rankwell-seo-checklist')}
                        </Button>
                        {window.rwscConfig?.autoCheck && keyword && (
                            <span className="rwsc-auto-badge">
                                {__('Auto-check enabled', 'rankwell-seo-checklist')}
                            </span>
                        )}
                    </div>
                    
                    {error && (
                        <Notice status="error" isDismissible={false}>
                            {error}
                        </Notice>
                    )}
                    
                    {score !== null && (
                        <div className="rwsc-gutenberg-results">
                            <div className="rwsc-score-section">
                                <div className="rwsc-score-header">
                                    <strong>{__('Score:', 'rankwell-seo-checklist')}</strong>
                                    <span className={`rwsc-score-value rwsc-score-${score >= 80 ? 'good' : (score >= 60 ? 'warning' : 'poor')}`}>
                                        {score}/100
                                    </span>
                                </div>
                                <div className="rwsc-progress">
                                    <div 
                                        className="rwsc-progress-fill" 
                                        style={{ width: `${score}%`, backgroundColor: getStatusColor(score >= 80 ? 'pass' : (score >= 60 ? 'warning' : 'fail')) }}
                                    />
                                </div>
                            </div>
                            
                            {checks.length > 0 && (
                                <div className="rwsc-checks-section">
                                    <h4>{__('Checks', 'rankwell-seo-checklist')}</h4>
                                    <div className="rwsc-checks-list">
                                        {checks.map((check, index) => (
                                            <div key={index} className={`rwsc-check-item rwsc-status-${check.status}`}>
                                                <div className="rwsc-check-info">
                                                    <div className="rwsc-check-label">{check.label}</div>
                                                    <div className="rwsc-check-desc">{check.description}</div>
                                                </div>
                                                <div className="rwsc-check-badge">{check.status}</div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}
                            
                            {suggestions.length > 0 && (
                                <div className="rwsc-suggestions-section">
                                    <h4>{__('Suggestions for Improvement', 'rankwell-seo-checklist')}</h4>
                                    {suggestions.map((suggestion, index) => (
                                        <div key={index} className="rwsc-suggestion-item">
                                            <div className="rwsc-suggestion-header">
                                                <span className={`rwsc-priority rwsc-priority-${suggestion.priority}`}>
                                                    {getPriorityLabel(suggestion.priority)}
                                                </span>
                                                <strong>{suggestion.title}</strong>
                                            </div>
                                            <div className="rwsc-suggestion-message">{suggestion.message}</div>
                                            <div className="rwsc-suggestion-action">{suggestion.action}</div>
                                            {suggestion.examples && suggestion.examples.length > 0 && (
                                                <ul className="rwsc-suggestion-examples">
                                                    {suggestion.examples.map((example, i) => (
                                                        <li key={i}>{example}</li>
                                                    ))}
                                                </ul>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>
                    )}
                    
                    {loading && (
                        <div className="rwsc-loading-gutenberg">
                            <Spinner />
                            <span>{__('Running checks...', 'rankwell-seo-checklist')}</span>
                        </div>
                    )}
                </div>
                
                <style>{`
                    .rwsc-gutenberg-panel .components-panel__body-title {
                        background: #f0f0f1;
                    }
                    .rwsc-gutenberg-container {
                        padding: 4px 0;
                    }
                    .rwsc-keyword-field {
                        margin-bottom: 16px;
                    }
                    .rwsc-actions {
                        margin-bottom: 16px;
                        display: flex;
                        align-items: center;
                        gap: 12px;
                    }
                    .rwsc-auto-badge {
                        font-size: 11px;
                        color: #646970;
                    }
                    .rwsc-score-section {
                        margin-bottom: 20px;
                        padding: 12px;
                        background: #f8f9fa;
                        border-radius: 4px;
                    }
                    .rwsc-score-header {
                        display: flex;
                        justify-content: space-between;
                        margin-bottom: 8px;
                    }
                    .rwsc-score-value {
                        font-weight: 600;
                    }
                    .rwsc-score-good {
                        color: #00a32a;
                    }
                    .rwsc-score-warning {
                        color: #dba617;
                    }
                    .rwsc-score-poor {
                        color: #d63638;
                    }
                    .rwsc-progress {
                        height: 6px;
                        background: #e0e0e0;
                        border-radius: 3px;
                        overflow: hidden;
                    }
                    .rwsc-progress-fill {
                        height: 100%;
                        transition: width 0.3s ease;
                    }
                    .rwsc-checks-section {
                        margin-bottom: 20px;
                    }
                    .rwsc-checks-section h4 {
                        margin: 0 0 12px 0;
                        font-size: 13px;
                        font-weight: 600;
                    }
                    .rwsc-checks-list {
                        max-height: 300px;
                        overflow-y: auto;
                    }
                    .rwsc-check-item {
                        display: flex;
                        justify-content: space-between;
                        align-items: flex-start;
                        padding: 8px 0;
                        border-bottom: 1px solid #f0f0f1;
                    }
                    .rwsc-check-info {
                        flex: 1;
                    }
                    .rwsc-check-label {
                        font-weight: 500;
                        margin-bottom: 2px;
                    }
                    .rwsc-check-desc {
                        font-size: 11px;
                        color: #646970;
                    }
                    .rwsc-check-badge {
                        font-size: 10px;
                        font-weight: 600;
                        padding: 2px 8px;
                        border-radius: 10px;
                        text-transform: uppercase;
                        margin-left: 8px;
                    }
                    .rwsc-status-pass .rwsc-check-badge {
                        background: #d1f7c4;
                        color: #0c5b29;
                    }
                    .rwsc-status-warning .rwsc-check-badge {
                        background: #fef7f1;
                        color: #8a4b00;
                    }
                    .rwsc-status-fail .rwsc-check-badge {
                        background: #fcf0f1;
                        color: #8a2424;
                    }
                    .rwsc-status-info .rwsc-check-badge {
                        background: #f0f6fc;
                        color: #006ba1;
                    }
                    .rwsc-suggestions-section h4 {
                        margin: 0 0 12px 0;
                        font-size: 13px;
                        font-weight: 600;
                    }
                    .rwsc-suggestion-item {
                        padding: 12px;
                        background: #f8f9fa;
                        border-radius: 4px;
                        margin-bottom: 12px;
                    }
                    .rwsc-suggestion-header {
                        display: flex;
                        align-items: center;
                        gap: 8px;
                        margin-bottom: 8px;
                        flex-wrap: wrap;
                    }
                    .rwsc-priority {
                        font-size: 9px;
                        font-weight: 600;
                        padding: 2px 6px;
                        border-radius: 10px;
                        text-transform: uppercase;
                    }
                    .rwsc-priority-high {
                        background: #fcf0f1;
                        color: #8a2424;
                    }
                    .rwsc-priority-medium {
                        background: #fef7f1;
                        color: #8a4b00;
                    }
                    .rwsc-priority-low {
                        background: #f0f6fc;
                        color: #006ba1;
                    }
                    .rwsc-suggestion-message {
                        font-size: 12px;
                        color: #50575e;
                        margin-bottom: 6px;
                    }
                    .rwsc-suggestion-action {
                        font-size: 11px;
                        color: #646970;
                        font-style: italic;
                    }
                    .rwsc-suggestion-examples {
                        margin-top: 8px;
                        padding-left: 16px;
                        font-size: 11px;
                        color: #646970;
                    }
                    .rwsc-loading-gutenberg {
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        gap: 8px;
                        padding: 20px;
                        color: #646970;
                    }
                `}</style>
            </PluginDocumentSettingPanel>
        );
    };

    // Register the plugin
    registerPlugin('rankwell-seo-checklist', {
        render: RankwellSEOPanel,
        icon: null,
    });
})();