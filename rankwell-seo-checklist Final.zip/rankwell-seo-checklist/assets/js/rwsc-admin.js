(function($) {
    'use strict';
    
    const RankwellChecklist = {
        config: {},
        debounceTimer: null,
        isRunning: false,
        currentChecks: [],
        
        init: function() {
            this.config = window.rwscConfig || {};
            this.bindEvents();
            
            // Auto-run if keyword exists and auto-check is enabled
            if (this.config.autoCheck && $('#rwsc_focus_keyword').val().trim().length >= 2) {
                setTimeout(() => this.runChecklist(), 1000);
            }
        },
        
        bindEvents: function() {
            const self = this;
            
            // Run checklist button
            $('#rwsc_run_check').on('click', function(e) {
                e.preventDefault();
                self.runChecklist();
            });
            
            // Keyword input with debounce
            $('#rwsc_focus_keyword').on('input', function() {
                self.debounce(() => {
                    self.saveKeyword();
                    if (self.config.autoCheck) {
                        self.runChecklist();
                    }
                }, self.config.debounceTime || 2000);
            });
            
            // Save on blur
            $('#rwsc_focus_keyword').on('blur', function() {
                self.saveKeyword();
            });
        },
        
        debounce: function(callback, delay) {
            clearTimeout(this.debounceTimer);
            this.debounceTimer = setTimeout(callback, delay);
        },
        
        saveKeyword: function() {
            const keyword = $('#rwsc_focus_keyword').val().trim();
            const postId = this.config.postId;
            
            if (!postId) return;
            
            $.ajax({
                url: this.config.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'rwsc_save_keyword',
                    post_id: postId,
                    keyword: keyword,
                    nonce: this.config.nonce
                },
                beforeSend: () => {},
                success: (response) => {
                    if (response.success && this.config.debug) {
                        console.log('Keyword saved:', response.data);
                    }
                },
                error: (xhr, status, error) => {
                    console.error(this.config.i18n.error, error);
                    this.showMessage(this.config.i18n.error + ' ' + error, 'error');
                }
            });
        },
        
        runChecklist: function() {
            if (this.isRunning) return;
            
            const keyword = $('#rwsc_focus_keyword').val().trim();
            const postId = this.config.postId;
            
            if (!keyword || keyword.length < 2) {
                this.showMessage(this.config.i18n.enterKeyword, 'warning');
                return;
            }
            
            // Get content from editor
            const content = this.getEditorContent();
            if (!content) {
                this.showMessage(this.config.i18n.noContent, 'warning');
                return;
            }
            
            this.isRunning = true;
            this.showLoading(true);
            this.showResults(false);
            
            // Use AJAX
            this.runChecklistViaAjax(postId, keyword, content);
        },
        
        runChecklistViaAjax: function(postId, keyword, content) {
            $.ajax({
                url: this.config.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'rwsc_run_preflight',
                    post_id: postId,
                    keyword: keyword,
                    content: content,
                    nonce: this.config.nonce
                },
                success: (response) => {
                    if (response.success) {
                        this.displayResults(response.data);
                    } else {
                        this.showMessage(response.data?.message || this.config.i18n.error, 'error');
                    }
                },
                error: (xhr) => {
                    let message = this.config.i18n.error;
                    if (xhr.status === 403) {
                        message = __('Security check failed. Please refresh the page.', 'rankwell-seo-checklist');
                    } else if (xhr.status === 429) {
                        message = __('Rate limit exceeded. Please wait a moment.', 'rankwell-seo-checklist');
                    } else if (xhr.responseJSON?.data?.message) {
                        message = xhr.responseJSON.data.message;
                    }
                    this.showMessage(message, 'error');
                },
                complete: () => {
                    this.isRunning = false;
                    this.showLoading(false);
                }
            });
        },
        
        getEditorContent: function() {
            // Try Gutenberg editor first
            if (window.wp && wp.data && wp.data.select) {
                try {
                    const editor = wp.data.select('core/editor');
                    if (editor && editor.getEditedPostContent) {
                        return editor.getEditedPostContent();
                    }
                } catch (e) {
                    // Fall through to classic editor
                }
            }
            
            // Try Classic Editor (TinyMCE)
            if (typeof tinymce !== 'undefined' && tinymce.get('content')) {
                const editor = tinymce.get('content');
                if (editor && !editor.isHidden()) {
                    return editor.getContent();
                }
            }
            
            // Fallback to textarea
            const textarea = document.getElementById('content');
            if (textarea) {
                return textarea.value || '';
            }
            
            return '';
        },
        
        displayResults: function(data) {
            // Store current checks
            this.currentChecks = data.checks || [];
            
            // Update score with animation
            const $scoreValue = $('.rwsc-score-value');
            const oldScore = parseInt($scoreValue.text()) || 0;
            const newScore = data.score || 0;
            
            $scoreValue
                .removeClass('updated')
                .text(newScore)
                .addClass('updated');
            
            // Update progress bar with color coding
            const progress = Math.min(100, newScore);
            const $progressFill = $('.rwsc-progress-fill');
            $progressFill.css('width', progress + '%');
            
            // Color code based on score
            let scoreColor = '#d63638';
            if (newScore >= 80) {
                scoreColor = '#00a32a';
            } else if (newScore >= 60) {
                scoreColor = '#dba617';
            }
            
            $progressFill.css('background', scoreColor);
            
            // Color code the score text
            $scoreValue
                .removeClass('rwsc-score-good rwsc-score-warning rwsc-score-poor')
                .css('color', scoreColor);
            
            if (newScore >= 80) {
                $scoreValue.addClass('rwsc-score-good');
            } else if (newScore >= 60) {
                $scoreValue.addClass('rwsc-score-warning');
            } else {
                $scoreValue.addClass('rwsc-score-poor');
            }
            
            // Build checklist
            this.buildChecklist(data.checks);
            
            // Build suggestions
            this.buildSuggestions(data.suggestions);
            
            // Show results container
            this.showResults(true);
            
            // Show summary message based on score
            this.showSummaryMessage(newScore);
            
            // Log performance data if available
            if (data.performance && this.config.debug) {
                console.log('Checklist Performance:', data.performance);
            }
        },
        
        buildChecklist: function(checks) {
            const $checklist = $('.rwsc-checklist').empty();
            
            if (!checks || !checks.length) {
                $checklist.html('<p class="rwsc-no-checks">' + this.config.i18n.noChecks + '</p>');
                return;
            }
            
            // Display all checks
            checks.forEach(check => {
                const statusIcon = this.getStatusIcon(check.status);
                const item = $(`
                    <div class="rwsc-check-item rwsc-status-${check.status}" 
                         data-check-id="${check.id}">
                        <div class="rwsc-check-info">
                            <div class="rwsc-check-label">${this.escapeHtml(check.label)}</div>
                            <div class="rwsc-check-description">${statusIcon} ${this.escapeHtml(check.description)}</div>
                        </div>
                        <div class="rwsc-check-status">${check.status}</div>
                    </div>
                `);
                
                // Add toggle functionality if check is disabled
                if (this.config.enabledChecks && !this.config.enabledChecks[check.id]) {
                    item.addClass('rwsc-check-disabled');
                    item.find('.rwsc-check-status').text('disabled');
                }
                
                $checklist.append(item);
            });
        },
        
        getStatusIcon: function(status) {
            const icons = {
                'pass': '✓',
                'warning': '⚠',
                'fail': '✗',
                'info': 'ℹ'
            };
            return icons[status] || '';
        },
        
        buildSuggestions: function(suggestions) {
            const $suggestions = $('.rwsc-suggestions').empty();
            
            if (!suggestions || !suggestions.length) {
                $suggestions.hide();
                return;
            }
            
            $suggestions.show();
            
            // Add suggestions header
            $suggestions.append('<h4>' + this.config.i18n.suggestions + '</h4>');
            
            suggestions.forEach(suggestion => {
                let examplesHtml = '';
                if (suggestion.examples && suggestion.examples.length) {
                    const examplesList = suggestion.examples.map(ex => 
                        `<li>${this.escapeHtml(ex)}</li>`
                    ).join('');
                    
                    examplesHtml = `<ul class="rwsc-suggestion-examples">${examplesList}</ul>`;
                }
                
                const item = $(`
                    <div class="rwsc-suggestion rwsc-priority-${suggestion.priority}">
                        <div class="rwsc-suggestion-title">
                            <span class="rwsc-priority-badge rwsc-priority-${suggestion.priority}">
                                ${this.getPriorityLabel(suggestion.priority)}
                            </span>
                            ${this.escapeHtml(suggestion.title)}
                        </div>
                        <div class="rwsc-suggestion-message">${this.escapeHtml(suggestion.message)}</div>
                        <div class="rwsc-suggestion-action">${this.escapeHtml(suggestion.action)}</div>
                        ${examplesHtml}
                    </div>
                `);
                
                $suggestions.append(item);
            });
        },
        
        getPriorityLabel: function(priority) {
            const labels = {
                'high': __('High', 'rankwell-seo-checklist'),
                'medium': __('Medium', 'rankwell-seo-checklist'),
                'low': __('Low', 'rankwell-seo-checklist')
            };
            return labels[priority] || priority;
        },
        
        showSummaryMessage: function(score) {
            let message = '';
            let type = 'info';
            
            if (score >= 90) {
                message = __('Excellent! All checks passed.', 'rankwell-seo-checklist');
                type = 'success';
            } else if (score >= 80) {
                message = __('Good! Minor improvements possible.', 'rankwell-seo-checklist');
                type = 'success';
            } else if (score >= 60) {
                message = __('Fair. Some issues need attention.', 'rankwell-seo-checklist');
                type = 'warning';
            } else {
                message = __('Needs work. Multiple issues found.', 'rankwell-seo-checklist');
                type = 'error';
            }
            
            this.showMessage(message, type);
        },
        
        showLoading: function(show) {
            if (show) {
                $('.rwsc-loading').show();
                $('#rwsc_run_check').prop('disabled', true).text(this.config.i18n.analyzing);
            } else {
                $('.rwsc-loading').hide();
                $('#rwsc_run_check').prop('disabled', false).text('Run Checklist');
            }
        },
        
        showResults: function(show) {
            if (show) {
                $('.rwsc-results-container').show();
            } else {
                $('.rwsc-results-container').hide();
            }
        },
        
        showMessage: function(message, type = 'info') {
            const $container = $('.rwsc-results-container');
            
            // Clear existing messages
            $('.rwsc-message').remove();
            
            const messageClass = 'rwsc-message rwsc-message-' + type;
            const $message = $(`<div class="${messageClass}">${this.escapeHtml(message)}</div>`);
            
            $container.prepend($message);
            $container.show();
            
            // Auto-remove after 5 seconds for non-error messages
            if (type !== 'error') {
                setTimeout(() => $message.fadeOut(300, () => $message.remove()), 5000);
            }
        },
        
        escapeHtml: function(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
    };
    
    // Helper for WordPress translations
    function __(text, domain) {
        if (window.wp && wp.i18n && wp.i18n.__) {
            return wp.i18n.__(text, domain);
        }
        return text;
    }
    
    // Initialize when DOM is ready
    $(document).ready(() => {
        RankwellChecklist.init();
    });
    
})(jQuery);