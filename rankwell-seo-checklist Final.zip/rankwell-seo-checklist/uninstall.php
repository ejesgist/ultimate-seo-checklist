<?php
/**
 * Uninstall Rankwell SEO Checklist
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Check if we should delete all data
$delete_all_data = get_option('rwsc_delete_data_on_uninstall', 0);

if ($delete_all_data) {
    global $wpdb;
    
    // Delete all focus keywords
    $wpdb->query(
        $wpdb->prepare(
            "DELETE FROM {$wpdb->postmeta} WHERE meta_key = %s",
            '_rwsc_focus_keyword'
        )
    );
    
    // Delete cache table
    $table_name = $wpdb->prefix . 'rwsc_cache';
    $wpdb->query("DROP TABLE IF EXISTS {$table_name}");
    
    // Clean up indexes
    $wpdb->query("ALTER TABLE {$wpdb->postmeta} DROP INDEX IF EXISTS rwsc_keyword_idx");
    
    // Delete options
    $options = [
        'rwsc_version',
        'rwsc_auto_check',
        'rwsc_cache_duration',
        'rwsc_compatibility_mode',
        'rwsc_minimal_mode',
        'rwsc_enabled_checks',
        'rwsc_delete_data_on_uninstall'
    ];
    
    foreach ($options as $option) {
        delete_option($option);
    }
    
    // Clear any transients
    $wpdb->query(
        $wpdb->prepare(
            "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
            '_transient_rwsc_%',
            '_transient_timeout_rwsc_%'
        )
    );
    
    // Log uninstallation
    if (defined('WP_DEBUG') && WP_DEBUG) {
        error_log('Rankwell SEO Checklist completely uninstalled with data removal');
    }
} else {
    // Just log uninstallation
    if (defined('WP_DEBUG') && WP_DEBUG) {
        error_log('Rankwell SEO Checklist uninstalled (data preserved)');
    }
}