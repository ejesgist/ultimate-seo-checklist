=== Rankwell SEO Checklist ===
Contributors: ejesgist
Donate link: https://github.com/ejesgist
Tags: seo, on-page seo, seo audit, content optimization, search engine optimization
Requires at least: 6.0
Tested up to: 6.9
Requires PHP: 8.0
Stable tag: 1.3.0
License: GPL v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A lightweight on-page SEO checklist and audit tool designed as a preflight check for content before publishing.

== Description ==

Rankwell SEO Checklist is a lightweight on-page SEO checklist and audit tool designed as a preflight check for content before publishing. It validates essential on-page SEO requirements and works alongside Yoast SEO, Rank Math, and other SEO plugins.

**Requirements:**
* WordPress 6.0 or higher
* PHP 8.0 or higher

**Features:**

*   **Lightweight & Fast:** Minimal impact on site performance
*   **SEO Plugin Compatible:** Works alongside major SEO plugins
*   **Page Builder Support:** Works with Elementor, Beaver Builder, WPBakery, Divi, and more
*   **Real-time Analysis:** Check SEO as you type with auto-refresh
*   **Essential Checks:** 40+ SEO checks including keyword analysis, readability, and content quality
*   **Smart Caching:** Configurable cache durations for optimal performance
*   **Minimal Mode:** Simplified interface for quick checks
*   **Actionable Suggestions:** Clear recommendations for improvement
*   **PHP 8.0+ Optimized:** Built for modern PHP versions

**Page Builder Compatibility:**
*   ✅ Gutenberg (Block Editor)
*   ✅ Classic Editor
*   ✅ Elementor
*   ✅ Beaver Builder
*   ✅ WPBakery Page Builder
*   ✅ Divi Builder
*   ✅ Bricks Builder
*   ✅ Oxygen Builder
*   ✅ Brizy

**Perfect For:**
*   Content creators who want a quick SEO check before publishing
*   SEO professionals who need a lightweight audit tool
*   Anyone using existing SEO plugins but wanting additional validation
*   Sites where performance is critical
*   Sites running on modern PHP versions

== Installation ==

1. Upload the `rankwell-seo-checklist` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to any post or page to see the SEO Checklist metabox
4. Enter your focus keyword and click "Run Checklist"

== Frequently Asked Questions ==

= Does this replace my existing SEO plugin? =

No! Rankwell SEO Checklist is designed to work alongside your existing SEO plugin (Yoast SEO, Rank Math, etc.). It provides a quick preflight check before publishing.

= Does this work with page builders? =

Yes! Rankwell SEO Checklist works with most popular page builders including:
* Elementor
* Beaver Builder
* WPBakery Page Builder
* Divi Builder
* Bricks Builder
* Oxygen Builder
* Brizy

The plugin automatically detects content from these builders for accurate analysis.

= What are the system requirements? =

The plugin requires:
* WordPress 6.0 or higher
* PHP 8.0 or higher
* MySQL 5.6 or higher / MariaDB 10.1 or higher

= Will this slow down my site? =

No, the plugin is designed to be lightweight. It only loads on post edit screens and uses intelligent caching to minimize performance impact. For very long content (>50,000 characters), it will only analyze the first portion to ensure optimal performance.

= What SEO plugins are compatible? =

The plugin is compatible with:
* Yoast SEO
* Rank Math
* All In One SEO
* SEOPress
* The SEO Framework

= Can I customize which checks are performed? =

Yes, you can enable/disable individual checks in the plugin settings page under SEO Checklist > Settings.

= Is it compatible with PHP 8.x? =

Yes, the plugin has been fully tested and optimized for PHP 8.0, 8.1, 8.2, 8.3, and 8.4.

== Changelog ==

= 1.3.0 =
* **Minimum Requirements Updated:** WordPress 6.0+, PHP 8.0+
* Complete plugin restructure with PSR-4 namespacing
* New WordPress-standard autoloader
* Added top-level admin menu
* Added support for major page builders (Elementor, Beaver Builder, WPBakery, Divi)
* Enhanced content extraction for page builders
* Added Gutenberg sidebar panel integration
* Added help tab with documentation
* Improved performance with content length limits
* PHP 8.4 compatibility and optimization
* Enhanced about page with plugin information
* Code organization improvements
* Updated branding to Rankwell SEO Checklist

= 1.2.0 =
* Added title word count check (5-9 words optimal)
* Enhanced power words detection with categories
* Added uncommon words detection
* Improved quick answer format detection
* Added transition words check
* Added paragraph structure analysis
* Added content conclusion detection
* Added image file size warning
* Enhanced suggestions with examples

= 1.1.0 =
* Added URL slug length check (≤65 characters)
* Added title power words analysis
* Added title sentiment analysis
* Added title number check
* Added quick answer format detection
* Added keyword as anchor text warning
* Added keyword bolded check
* Enhanced headings structure check

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.3.0 =
**Important:** This version now requires WordPress 6.0+ and PHP 8.0+. Please ensure your server meets these requirements before updating. Major update with PSR-4 namespacing, page builder support, Gutenberg integration, and PHP 8.4 compatibility.